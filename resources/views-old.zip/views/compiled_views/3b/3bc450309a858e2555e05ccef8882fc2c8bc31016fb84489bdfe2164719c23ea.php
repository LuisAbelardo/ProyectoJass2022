<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /administration/usuario/userDetail.twig */
class __TwigTemplate_77adcdb4a7c6920a0bd06356f5d8eda1ff99350565b8c9bef2f41b6c82861d6e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content_main' => [$this, 'block_content_main'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "administration/templateAdministration.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["menuLItem"] = "usuario";
        // line 3
        $this->parent = $this->loadTemplate("administration/templateAdministration.twig", "/administration/usuario/userDetail.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "\t
<div class=\"f_card\">

  \t<div class=\"row\">
  \t\t<div class=\"col-12\">
  \t\t\t<div class=\"f_cardheader\">
  \t\t\t\t<div class=\"\"> 
                \t<i class=\"fas fa-user-shield mr-3\"></i>Detalle de usuario 
            \t</div>
  \t\t\t</div>
  \t\t</div>
  \t</div><!-- /.card-header -->
  \t
  \t<div class=\"row\">
  \t\t<div class=\"col-12\">
  \t\t\t";
        // line 22
        echo "            ";
        $context["classAlert"] = "";
        // line 23
        echo "            ";
        if (twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 23, $this->source); })()))) {
            // line 24
            echo "            \t";
            $context["classAlert"] = "d-none";
            // line 25
            echo "            ";
        } elseif ((((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 25, $this->source); })()) >= 200) && ((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 25, $this->source); })()) < 300))) {
            // line 26
            echo "                ";
            $context["classAlert"] = "alert-success";
            // line 27
            echo "            ";
        } elseif (((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) >= 400)) {
            // line 28
            echo "                ";
            $context["classAlert"] = "alert-danger";
            // line 29
            echo "            ";
        }
        // line 30
        echo "  \t\t\t<div class=\"alert ";
        echo twig_escape_filter($this->env, (isset($context["classAlert"]) || array_key_exists("classAlert", $context) ? $context["classAlert"] : (function () { throw new RuntimeError('Variable "classAlert" does not exist.', 30, $this->source); })()), "html", null, true);
        echo " alert-dismissible fade show\" id=\"f_alertsContainer\" role=\"alert\">
             \t<ul class=\"mb-0\" id=\"f_alertsUl\">
             \t\t";
        // line 32
        if ( !twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 32, $this->source); })()))) {
            // line 33
            echo "                      ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 33, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["msj"]) {
                // line 34
                echo "                        <li>";
                echo twig_escape_filter($this->env, $context["msj"], "html", null, true);
                echo "</li>
                      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "                    ";
        }
        // line 37
        echo "             \t</ul>
             \t<button type=\"button\" class=\"close\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\" id=\"f_alertsDismiss\">
             \t\t<span aria-hidden=\"true\">&times;</span>
             \t</button>
            </div>";
        // line 42
        echo "  \t\t</div>
  \t</div>
  \t
  
  \t<div class=\"row\">
  \t\t<div class=\"col-12 d-flex justify-content-between f_arearef\">
  \t\t\t<div>
  \t\t\t\t<div class=\"d-inline-block mr-2 mr-md-4\">
  \t\t\t\t    ";
        // line 50
        $context["photoref"] = ((isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 50, $this->source); })()) . "/img/user_default.svg");
        // line 51
        echo "          \t\t\t";
        if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "photoref", [], "any", true, true, false, 51) &&  !twig_test_empty(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 51, $this->source); })()), "photoref", [], "any", false, false, false, 51)))) {
            // line 52
            echo "          \t\t\t    ";
            $context["photoref"] = twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 52, $this->source); })()), "photoref", [], "any", false, false, false, 52);
        }
        // line 53
        echo "      \t\t\t    <div class=\"f_imageref\"><img  src=\"";
        echo twig_escape_filter($this->env, (isset($context["photoref"]) || array_key_exists("photoref", $context) ? $context["photoref"] : (function () { throw new RuntimeError('Variable "photoref" does not exist.', 53, $this->source); })()), "html", null, true);
        echo "\"></div>
  \t\t\t\t</div>
  \t\t\t\t<div class=\"d-inline-block align-top\">
  \t\t\t\t\t<span class=\"font-weight-bold f_inforef\">
  \t\t\t\t\t    ";
        // line 57
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 57)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 57, $this->source); })()), "usuario", [], "any", false, false, false, 57), "USU_CODIGO", [], "any", false, false, false, 57), "html", null, true);
        }
        // line 58
        echo "  \t\t\t\t\t</span><br/>
  \t\t\t\t\t<span class=\"font-weight-bold f_inforef\">
  \t\t\t\t\t    ";
        // line 60
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 60)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 60, $this->source); })()), "usuario", [], "any", false, false, false, 60), "USU_USUARIO", [], "any", false, false, false, 60), "html", null, true);
        }
        // line 61
        echo "\t\t\t\t    </span><br/>
  \t\t\t\t\t<span><i class=\"fas fa-at mr-1\"></i>";
        // line 62
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 62)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 62, $this->source); })()), "usuario", [], "any", false, false, false, 62), "USU_EMAIL", [], "any", false, false, false, 62), "html", null, true);
        }
        echo "</span>
  \t\t\t\t</div>
  \t\t\t</div>
  \t\t\t<div class=\"d-none d-sm-block\">
  \t\t\t\t<span><a href=\"";
        // line 66
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 66, $this->source); })()), "html", null, true);
        echo "/usuario/lista\" class=\"f_link font-weight-bold\">Volver a Lista</a></span>
  \t\t\t</div>
  \t\t</div>
  \t\t<div class=\"col-12 col-lg-6 table-responsive\">
  \t\t\t<table class=\"table f_table f_tableforfield\">
              <tbody>
              \t<tr>
                  <td>Inicio de sesión / Id.</td>
                  <td>";
        // line 74
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 74)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 74, $this->source); })()), "usuario", [], "any", false, false, false, 74), "USU_CODIGO", [], "any", false, false, false, 74), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Inicio de sesión / Usuario</td>
                  <td>";
        // line 78
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 78)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 78, $this->source); })()), "usuario", [], "any", false, false, false, 78), "USU_USUARIO", [], "any", false, false, false, 78), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Tipo</td>
                  <td>";
        // line 82
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuarioTipo", [], "any", true, true, false, 82)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 82, $this->source); })()), "usuarioTipo", [], "any", false, false, false, 82), "TPU_NOMBRE", [], "any", false, false, false, 82), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Estado</td>
                  <td>
                  \t";
        // line 87
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 87)) {
            // line 88
            echo "                  \t\t";
            if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 88, $this->source); })()), "usuario", [], "any", false, false, false, 88), "USU_ESTADO", [], "any", false, false, false, 88) == 0)) {
                // line 89
                echo "                        \t<span class=\"badge badge-danger\">";
                echo "Suspendido";
                echo "</span>
                        ";
            } elseif ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source,             // line 90
(isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 90, $this->source); })()), "usuario", [], "any", false, false, false, 90), "USU_ESTADO", [], "any", false, false, false, 90) == 1)) {
                // line 91
                echo "                        \t<span class=\"badge badge-success\">";
                echo "Activo";
                echo "</span>
                        ";
            }
            // line 93
            echo "                  \t";
        }
        // line 94
        echo "                  </td>
                </tr>
                <tr>
                  <td>Fecha de creación</td>
                  <td>";
        // line 98
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 98)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 98, $this->source); })()), "usuario", [], "any", false, false, false, 98), "USU_CREATED", [], "any", false, false, false, 98), "html", null, true);
        }
        echo "</td>
                </tr>
              </tbody>
            </table>
  \t\t</div>
  \t\t<div class=\"col-12 col-lg-6  mt-3 mt-lg-0 table-responsive\">
  \t\t\t<table class=\"table f_table f_tableforfield\">
              <tbody>
              \t<tr>
                  <td>Nombre</td>
                  <td>";
        // line 108
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 108)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 108, $this->source); })()), "usuario", [], "any", false, false, false, 108), "USU_NOMBRES", [], "any", false, false, false, 108), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Apellidos</td>
                  <td>";
        // line 112
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 112)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 112, $this->source); })()), "usuario", [], "any", false, false, false, 112), "USU_APELLIDOS", [], "any", false, false, false, 112), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Correo</td>
                  <td>";
        // line 116
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 116)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 116, $this->source); })()), "usuario", [], "any", false, false, false, 116), "USU_EMAIL", [], "any", false, false, false, 116), "html", null, true);
        }
        echo "</td>
                </tr>
              </tbody>
            </table>
  \t\t</div>
  \t</div><!-- /.card-body -->
  \t
  \t<div class=\"row\">
  \t\t<div class=\"col-12\">
  \t\t\t<div class=\"f_cardfooter f_cardfooteractions text-right\">
  \t\t\t\t";
        // line 126
        if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 126) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 126, $this->source); })()), "usuario", [], "any", false, false, false, 126), "USU_INTENTOS_FALLIDOS", [], "any", false, false, false, 126) >= 3))) {
            // line 127
            echo "      \t\t\t\t";
            $context["titleBtnDesbloquear"] = "Desbloquear usuario por limite de intentos fallidos";
            // line 128
            echo "      \t\t\t\t<button type=\"button\" class=\"f_button f_buttonaction classfortooltip\" data-toggle=\"modal\" data-target=\"#modalDesbloquearUsuario\"
      \t\t\t\t\t\ttitle=\"";
            // line 129
            echo twig_escape_filter($this->env, (isset($context["titleBtnDesbloquear"]) || array_key_exists("titleBtnDesbloquear", $context) ? $context["titleBtnDesbloquear"] : (function () { throw new RuntimeError('Variable "titleBtnDesbloquear" does not exist.', 129, $this->source); })()), "html", null, true);
            echo "\">Desbloquear</button>
\t\t\t\t";
        }
        // line 131
        echo "  \t\t\t\t<a href=\"";
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 131, $this->source); })()), "html", null, true);
        echo "/usuario/editar/";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 131)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 131, $this->source); })()), "usuario", [], "any", false, false, false, 131), "USU_CODIGO", [], "any", false, false, false, 131), "html", null, true);
        }
        echo "\" 
  \t\t\t\t\tclass=\"f_linkbtn f_linkbtnaction\">Modificar</a>
\t\t\t\t";
        // line 133
        $context["titleBtnEliminar"] = "Los usuarios no pueden ser eliminados.
  \t\t\t\t\t\t\t\t\t\t\t Para quitar acceso al sistema puede suspender al usuario";
        // line 135
        echo "  \t\t\t\t<button type=\"button\" class=\"f_button f_buttonactionrefused classfortooltip\" data-toggle=\"modal\" data-target=\"#modalEliminarUsuario\"
  \t\t\t\t\t\ttitle=\"";
        // line 136
        echo twig_escape_filter($this->env, (isset($context["titleBtnEliminar"]) || array_key_exists("titleBtnEliminar", $context) ? $context["titleBtnEliminar"] : (function () { throw new RuntimeError('Variable "titleBtnEliminar" does not exist.', 136, $this->source); })()), "html", null, true);
        echo "\">Eliminar</button>
  \t\t\t</div>
  \t\t\t
  \t\t</div>
  \t</div><!-- /.card-footer -->
  
</div><!-- /.card -->



";
        // line 147
        if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 147) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 147, $this->source); })()), "usuario", [], "any", false, false, false, 147), "USU_INTENTOS_FALLIDOS", [], "any", false, false, false, 147) >= 3))) {
            // line 148
            echo "<div class=\"modal fade f_modal\" id=\"modalDesbloquearUsuario\" tabindex=\"-1\" role=\"dialog\" data-backdrop=\"static\" aria-hidden=\"true\">
    <div class=\"modal-dialog\" role=\"document\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"modal-title\">Desbloquear Usuario</span>
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                \t<span aria-hidden=\"true\">&times;</span>
                </button>
            </div>
            <div class=\"modal-body\">
            \t<i class=\"fas fa-info-circle text-secondary mr-1\"></i>
            \t<span>
                \tEste usuario fue bloqueado por superar el limite de intentos fallidos al intentar acceder al sistema
                \t¿Está seguro de querer desbloquear al usuario?</span>
            \t<form class=\"d-none\" id=\"formDesbloquearUsuario\" action=\"";
            // line 162
            echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 162, $this->source); })()), "html", null, true);
            echo "/usuario/unlock/intentosfallidos\" method=\"post\">
            \t\t<input type=\"hidden\" name=\"codigo\" value=\"";
            // line 163
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 163)) {
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 163, $this->source); })()), "usuario", [], "any", false, false, false, 163), "USU_CODIGO", [], "any", false, false, false, 163), "html", null, true);
            }
            echo "\">
            \t</form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"f_btnactionmodal\" id=\"btnDesbloquearUsuario\">Si</button>
                <button type=\"button\" class=\"f_btnactionmodal\" data-dismiss=\"modal\">No</button>
            </div>
        </div>
    </div>
</div>
";
        }
        // line 175
        echo "
    
";
    }

    // line 179
    public function block_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 180
        echo "
\t";
        // line 181
        $this->displayParentBlock("scripts", $context, $blocks);
        echo "
\t
\t<script type=\"text/javascript\">
\t\t\$('#btnDesbloquearUsuario').click(function(event){
\t\t\t\$('#formDesbloquearUsuario').submit();
\t\t\treturn false;
\t\t});
\t</script>
\t
";
    }

    public function getTemplateName()
    {
        return "/administration/usuario/userDetail.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  384 => 181,  381 => 180,  377 => 179,  371 => 175,  355 => 163,  351 => 162,  335 => 148,  333 => 147,  320 => 136,  317 => 135,  314 => 133,  304 => 131,  299 => 129,  296 => 128,  293 => 127,  291 => 126,  276 => 116,  267 => 112,  258 => 108,  243 => 98,  237 => 94,  234 => 93,  228 => 91,  226 => 90,  221 => 89,  218 => 88,  216 => 87,  206 => 82,  197 => 78,  188 => 74,  177 => 66,  168 => 62,  165 => 61,  161 => 60,  157 => 58,  153 => 57,  145 => 53,  141 => 52,  138 => 51,  136 => 50,  126 => 42,  120 => 37,  117 => 36,  108 => 34,  103 => 33,  101 => 32,  95 => 30,  92 => 29,  89 => 28,  86 => 27,  83 => 26,  80 => 25,  77 => 24,  74 => 23,  71 => 22,  54 => 6,  50 => 5,  45 => 3,  43 => 1,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("", "/administration/usuario/userDetail.twig", "/home/jasschos/public_html/resources/views/administration/usuario/userDetail.twig");
    }
}
