<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /administration/cliente/clienteEditNatural.twig */
class __TwigTemplate_e166dc9ef351a339d8204556832526a25429e8b61150572f4dad136eca15c7f1 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content_main' => [$this, 'block_content_main'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "administration/templateAdministration.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["menuLItem"] = "cliente";
        // line 3
        $this->parent = $this->loadTemplate("administration/templateAdministration.twig", "/administration/cliente/clienteEditNatural.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "
<div class=\"f_card\">
\t";
        // line 9
        echo "\t<form class=\"f_inputflat\" id=\"formEditarCliente\" method=\"post\" action=\"";
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 9, $this->source); })()), "html", null, true);
        echo "/cliente/update\">
\t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t<div class=\"f_cardheader\">
      \t\t\t\t<div class=\"\"> 
                    \t<i class=\"fas fa-user mr-3\"></i>Editar cliente
                \t</div>
      \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-header -->
      \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t";
        // line 24
        echo "                ";
        $context["classAlert"] = "";
        // line 25
        echo "                ";
        if (twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 25, $this->source); })()))) {
            // line 26
            echo "                \t";
            $context["classAlert"] = "d-none";
            // line 27
            echo "                ";
        } elseif ((((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) >= 200) && ((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) < 300))) {
            // line 28
            echo "                    ";
            $context["classAlert"] = "alert-success";
            // line 29
            echo "                ";
        } elseif (((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 29, $this->source); })()) >= 400)) {
            // line 30
            echo "                    ";
            $context["classAlert"] = "alert-danger";
            // line 31
            echo "                ";
        }
        // line 32
        echo "      \t\t\t<div class=\"alert ";
        echo twig_escape_filter($this->env, (isset($context["classAlert"]) || array_key_exists("classAlert", $context) ? $context["classAlert"] : (function () { throw new RuntimeError('Variable "classAlert" does not exist.', 32, $this->source); })()), "html", null, true);
        echo " alert-dismissible fade show\" id=\"f_alertsContainer\" role=\"alert\">
                 \t<ul class=\"mb-0\" id=\"f_alertsUl\">
                 \t\t";
        // line 34
        if ( !twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 34, $this->source); })()))) {
            // line 35
            echo "                          ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 35, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["msj"]) {
                // line 36
                echo "                            <li>";
                echo twig_escape_filter($this->env, $context["msj"], "html", null, true);
                echo "</li>
                          ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "                        ";
        }
        // line 39
        echo "                 \t</ul>
                 \t<button type=\"button\" class=\"close\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\" id=\"f_alertsDismiss\">
                 \t\t<span aria-hidden=\"true\">&times;</span>
                 \t</button>
                </div>";
        // line 44
        echo "      \t\t</div>
      \t</div>
      \t
  
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t
      \t\t\t<div class=\"f_divwithbartop f_divwithbarbottom\">
      \t\t\t\t<div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_field\">Ref.</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 55
        $context["codigo"] = "";
        // line 56
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 56)) {
            $context["codigo"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 56, $this->source); })()), "cliente", [], "any", false, false, false, 56), "CLI_CODIGO", [], "any", false, false, false, 56);
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 56, $this->source); })()), "cliente", [], "any", false, false, false, 56), "CLI_CODIGO", [], "any", false, false, false, 56), "html", null, true);
            echo "
                        \t";
        } elseif (twig_get_attribute($this->env, $this->source,         // line 57
($context["data"] ?? null), "formEditarCliente", [], "any", true, true, false, 57)) {
            // line 58
            echo "                        \t    ";
            $context["codigo"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 58, $this->source); })()), "formEditarCliente", [], "any", false, false, false, 58), "codigo", [], "any", false, false, false, 58);
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 58, $this->source); })()), "formEditarCliente", [], "any", false, false, false, 58), "codigo", [], "any", false, false, false, 58), "html", null, true);
        }
        // line 59
        echo "                        \t<input type=\"hidden\" class=\"f_minwidth300\" id=\"inpCodigo\" name=\"codigo\" value='";
        echo twig_escape_filter($this->env, (isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 59, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row d-none\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpTipo\">Tipo</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t<input type=\"hidden\" class=\"f_minwidth300\" id=\"inpTipo\" name=\"tipo\" value='1'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpDocumento\">DNI</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 71
        $context["documento"] = "";
        // line 72
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 72)) {
            $context["documento"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 72, $this->source); })()), "cliente", [], "any", false, false, false, 72), "CLI_DOCUMENTO", [], "any", false, false, false, 72);
            // line 73
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarCliente", [], "any", true, true, false, 73)) {
            $context["documento"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 73, $this->source); })()), "formEditarCliente", [], "any", false, false, false, 73), "documento", [], "any", false, false, false, 73);
        }
        // line 74
        echo "                        \t<input type=\"text\" class=\"f_minwidth300\" id=\"inpDocumento\" name=\"documento\" maxlength=\"8\" required value='";
        echo twig_escape_filter($this->env, (isset($context["documento"]) || array_key_exists("documento", $context) ? $context["documento"] : (function () { throw new RuntimeError('Variable "documento" does not exist.', 74, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpNombres\">Nombre</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 80
        $context["nombres"] = "";
        // line 81
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 81)) {
            $context["nombres"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 81, $this->source); })()), "cliente", [], "any", false, false, false, 81), "CLI_NOMBRES", [], "any", false, false, false, 81);
            // line 82
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarCliente", [], "any", true, true, false, 82)) {
            $context["nombres"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 82, $this->source); })()), "formEditarCliente", [], "any", false, false, false, 82), "nombres", [], "any", false, false, false, 82);
        }
        // line 83
        echo "                        \t<input type=\"text\" class=\"f_minwidth300\" id=\"inpNombres\" name=\"nombres\" required value='";
        echo twig_escape_filter($this->env, (isset($context["nombres"]) || array_key_exists("nombres", $context) ? $context["nombres"] : (function () { throw new RuntimeError('Variable "nombres" does not exist.', 83, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpFechaNacimiento\">Fecha Nacimiento</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 89
        $context["fechanacimiento"] = "";
        // line 90
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 90)) {
            $context["fechanacimiento"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 90, $this->source); })()), "cliente", [], "any", false, false, false, 90), "CLI_FECHA_NAC", [], "any", false, false, false, 90);
            // line 91
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarCliente", [], "any", true, true, false, 91)) {
            $context["fechanacimiento"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 91, $this->source); })()), "formEditarCliente", [], "any", false, false, false, 91), "fechanacimiento", [], "any", false, false, false, 91);
        }
        // line 92
        echo "                        \t<input type=\"date\" class=\"f_minwidth300\" id=\"inpFechaNacimiento\" name=\"fechanacimiento\" required value='";
        echo twig_escape_filter($this->env, (isset($context["fechanacimiento"]) || array_key_exists("fechanacimiento", $context) ? $context["fechanacimiento"] : (function () { throw new RuntimeError('Variable "fechanacimiento" does not exist.', 92, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpDepartamento\">Departamento</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 98
        $context["departamento"] = "";
        // line 99
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 99)) {
            $context["departamento"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 99, $this->source); })()), "cliente", [], "any", false, false, false, 99), "CLI_DEPARTAMENTO", [], "any", false, false, false, 99);
            // line 100
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarCliente", [], "any", true, true, false, 100)) {
            $context["departamento"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 100, $this->source); })()), "formEditarCliente", [], "any", false, false, false, 100), "departamento", [], "any", false, false, false, 100);
        }
        // line 101
        echo "                        \t<input type=\"text\" class=\"f_minwidth300\" id=\"inpDepartamento\" name=\"departamento\" required value='";
        echo twig_escape_filter($this->env, (isset($context["departamento"]) || array_key_exists("departamento", $context) ? $context["departamento"] : (function () { throw new RuntimeError('Variable "departamento" does not exist.', 101, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpProvincia\">Provincia</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 107
        $context["provincia"] = "";
        // line 108
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 108)) {
            $context["provincia"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 108, $this->source); })()), "cliente", [], "any", false, false, false, 108), "CLI_PROVINCIA", [], "any", false, false, false, 108);
            // line 109
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarCliente", [], "any", true, true, false, 109)) {
            $context["provincia"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 109, $this->source); })()), "formEditarCliente", [], "any", false, false, false, 109), "provincia", [], "any", false, false, false, 109);
        }
        // line 110
        echo "                        \t<input type=\"text\" class=\"f_minwidth300\" id=\"inpProvincia\" name=\"provincia\" required value='";
        echo twig_escape_filter($this->env, (isset($context["provincia"]) || array_key_exists("provincia", $context) ? $context["provincia"] : (function () { throw new RuntimeError('Variable "provincia" does not exist.', 110, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpDistrito\">Distrito</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 116
        $context["distrito"] = "";
        // line 117
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 117)) {
            $context["distrito"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 117, $this->source); })()), "cliente", [], "any", false, false, false, 117), "CLI_DISTRITO", [], "any", false, false, false, 117);
            // line 118
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarCliente", [], "any", true, true, false, 118)) {
            $context["distrito"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 118, $this->source); })()), "formEditarCliente", [], "any", false, false, false, 118), "distrito", [], "any", false, false, false, 118);
        }
        // line 119
        echo "                        \t<input type=\"text\" class=\"f_minwidth300\" id=\"inpDistrito\" name=\"distrito\" required value='";
        echo twig_escape_filter($this->env, (isset($context["distrito"]) || array_key_exists("distrito", $context) ? $context["distrito"] : (function () { throw new RuntimeError('Variable "distrito" does not exist.', 119, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpDireccion\">Dirección</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 125
        $context["direccion"] = "";
        // line 126
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 126)) {
            $context["direccion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 126, $this->source); })()), "cliente", [], "any", false, false, false, 126), "CLI_DIRECCION", [], "any", false, false, false, 126);
            // line 127
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarCliente", [], "any", true, true, false, 127)) {
            $context["direccion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 127, $this->source); })()), "formEditarCliente", [], "any", false, false, false, 127), "direccion", [], "any", false, false, false, 127);
        }
        // line 128
        echo "                        \t<input type=\"text\" class=\"f_minwidth300\" id=\"inpDireccion\" name=\"direccion\" required value='";
        echo twig_escape_filter($this->env, (isset($context["direccion"]) || array_key_exists("direccion", $context) ? $context["direccion"] : (function () { throw new RuntimeError('Variable "direccion" does not exist.', 128, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_field\" for=\"inpTelefono\">Telefono</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 134
        $context["telefono"] = "";
        // line 135
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 135)) {
            $context["telefono"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 135, $this->source); })()), "cliente", [], "any", false, false, false, 135), "CLI_TELEFONO", [], "any", false, false, false, 135);
            // line 136
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarCliente", [], "any", true, true, false, 136)) {
            $context["telefono"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 136, $this->source); })()), "formEditarCliente", [], "any", false, false, false, 136), "telefono", [], "any", false, false, false, 136);
        }
        // line 137
        echo "                        \t<input type=\"text\" class=\"f_minwidth300\" id=\"inpTelefono\" name=\"telefono\" value='";
        echo twig_escape_filter($this->env, (isset($context["telefono"]) || array_key_exists("telefono", $context) ? $context["telefono"] : (function () { throw new RuntimeError('Variable "telefono" does not exist.', 137, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_field\" for=\"inpEmail\">Email</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                            ";
        // line 143
        $context["email"] = "";
        // line 144
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 144)) {
            $context["email"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 144, $this->source); })()), "cliente", [], "any", false, false, false, 144), "CLI_EMAIL", [], "any", false, false, false, 144);
            // line 145
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarCliente", [], "any", true, true, false, 145)) {
            $context["email"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 145, $this->source); })()), "formEditarCliente", [], "any", false, false, false, 145), "email", [], "any", false, false, false, 145);
        }
        // line 146
        echo "                        \t<input type=\"text\" class=\"f_minwidth250\" id=\"inpEmail\" name=\"email\" value='";
        echo twig_escape_filter($this->env, (isset($context["email"]) || array_key_exists("email", $context) ? $context["email"] : (function () { throw new RuntimeError('Variable "email" does not exist.', 146, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    
      \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-body -->
  \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
          \t\t<div class=\"f_cardfooter f_cardfooteractions text-center\">
        \t\t\t<button type=\"submit\" class=\"f_button f_buttonaction\">Guardar cambios</button>
        \t\t\t<a href=\"";
        // line 158
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 158, $this->source); })()), "html", null, true);
        echo "/cliente/lista\" class=\"f_linkbtn f_linkbtnaction\">Cancelar</a>
    \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-footer -->
  \t
  \t</form>";
        // line 164
        echo "  
</div><!-- /.card -->
    
";
    }

    // line 169
    public function block_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 170
        echo "
    ";
        // line 171
        $this->displayParentBlock("scripts", $context, $blocks);
        echo "
  
\t<script type=\"text/javascript\">
\t\t\$('#formEditarCliente').keypress(function(e) {
            if (e.which == 13) {
                return false;
            }
        });
        
        f_select2(\"#cmbTipo\");
\t</script>
";
    }

    public function getTemplateName()
    {
        return "/administration/cliente/clienteEditNatural.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  393 => 171,  390 => 170,  386 => 169,  379 => 164,  371 => 158,  355 => 146,  350 => 145,  346 => 144,  344 => 143,  334 => 137,  329 => 136,  325 => 135,  323 => 134,  313 => 128,  308 => 127,  304 => 126,  302 => 125,  292 => 119,  287 => 118,  283 => 117,  281 => 116,  271 => 110,  266 => 109,  262 => 108,  260 => 107,  250 => 101,  245 => 100,  241 => 99,  239 => 98,  229 => 92,  224 => 91,  220 => 90,  218 => 89,  208 => 83,  203 => 82,  199 => 81,  197 => 80,  187 => 74,  182 => 73,  178 => 72,  176 => 71,  160 => 59,  155 => 58,  153 => 57,  146 => 56,  144 => 55,  131 => 44,  125 => 39,  122 => 38,  113 => 36,  108 => 35,  106 => 34,  100 => 32,  97 => 31,  94 => 30,  91 => 29,  88 => 28,  85 => 27,  82 => 26,  79 => 25,  76 => 24,  58 => 9,  54 => 6,  50 => 5,  45 => 3,  43 => 1,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("", "/administration/cliente/clienteEditNatural.twig", "/home/jasschos/public_html/resources/views/administration/cliente/clienteEditNatural.twig");
    }
}
