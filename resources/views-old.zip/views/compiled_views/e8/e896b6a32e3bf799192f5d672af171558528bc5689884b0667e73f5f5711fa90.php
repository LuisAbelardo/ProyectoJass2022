<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* administration/access/recoveryPassword.twig */
class __TwigTemplate_711df40a21336acd664d0dbf1690ea5923bacd12951ffc5352d1e7adb420d458 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, user-scalable=1.0, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0\">
  <!-- Favicon -->
  <link rel=\"shortcut icon\" type=\"image/png\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 7, $this->source); })()), "html", null, true);
        echo "/img/favicon.ico\"/>
  <!-- Font Awesome -->
  <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css\" integrity=\"sha512-L7MWcK7FNPcwNqnLdZq86lTHYLdQqZaz5YcAgE+5cnGmlw8JT03QB2+oxL100UeB6RlzZLUxCGSS4/++mNZdxw==\" crossorigin=\"anonymous\" />
  <!-- Bootstrap -->
    <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css\" integrity=\"sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh\" crossorigin=\"anonymous\">
  <!-- AdminLTE -->
  <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css\">
  <!-- Custom Theme -->
  <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 15, $this->source); })()), "html", null, true);
        echo "/css/private.css\">
</head>
<body class=\"hold-transition login-page\">
    <div class=\"login-box\">
      <div class=\"card card-outline card-primary\">
        <div class=\"card-header text-center\">
        \t<a href=\"";
        // line 21
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 21, $this->source); })()), "html", null, true);
        echo "\" class=\"h1\"><b>J.A.S.S</b></a>
        </div>
        <div class=\"card-body\">
        \t
        \t<div class=\"row\">
          \t\t<div class=\"col-12\">
          \t\t\t";
        // line 28
        echo "                    ";
        $context["classAlert"] = "";
        // line 29
        echo "                    ";
        if (twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 29, $this->source); })()))) {
            // line 30
            echo "                    \t";
            $context["classAlert"] = "d-none";
            // line 31
            echo "                    ";
        } elseif ((((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 31, $this->source); })()) >= 200) && ((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 31, $this->source); })()) < 300))) {
            // line 32
            echo "                        ";
            $context["classAlert"] = "alert-success";
            // line 33
            echo "                    ";
        } elseif (((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 33, $this->source); })()) >= 400)) {
            // line 34
            echo "                        ";
            $context["classAlert"] = "alert-danger";
            // line 35
            echo "                    ";
        }
        // line 36
        echo "          \t\t\t<div class=\"alert ";
        echo twig_escape_filter($this->env, (isset($context["classAlert"]) || array_key_exists("classAlert", $context) ? $context["classAlert"] : (function () { throw new RuntimeError('Variable "classAlert" does not exist.', 36, $this->source); })()), "html", null, true);
        echo " alert-dismissible fade show\" id=\"f_alertsContainer\" role=\"alert\">
                     \t<ul class=\"mb-0\" id=\"f_alertsUl\">
                     \t\t";
        // line 38
        if ( !twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 38, $this->source); })()))) {
            // line 39
            echo "                              ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 39, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["msj"]) {
                // line 40
                echo "                                <li>";
                echo twig_escape_filter($this->env, $context["msj"], "html", null, true);
                echo "</li>
                              ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 42
            echo "                            ";
        }
        // line 43
        echo "                     \t</ul>
                     \t<button type=\"button\" class=\"close\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\" id=\"f_alertsDismiss\">
                     \t\t<span aria-hidden=\"true\">&times;</span>
                     \t</button>
                    </div>";
        // line 48
        echo "          \t\t</div>
          \t</div>
        \t
        \t
            <p class=\"login-box-msg\">¿Olvidaste tu contraseña? Aquí puede solicitar una nueva contraseña.</p>
            <form action=\"";
        // line 53
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 53, $this->source); })()), "html", null, true);
        echo "/create/tokenrecoverypassword\" method=\"post\">
                <div class=\"input-group mb-3\">
                  <input type=\"text\" class=\"form-control\" placeholder=\"Usuario\" name=\"usuario\" required>
                  <div class=\"input-group-append\">
                    <div class=\"input-group-text\">
                      <span class=\"fas fa-user\"></span>
                    </div>
                  </div>
                </div>
                <div class=\"input-group mb-3\">
                  <input type=\"email\" class=\"form-control\" placeholder=\"Email\" name=\"email\" required>
                  <div class=\"input-group-append\">
                    <div class=\"input-group-text\">
                      <span class=\"fas fa-envelope\"></span>
                    </div>
                  </div>
                </div>
                <div class=\"row\">
                  <div class=\"col-12\">
                    <button type=\"submit\" class=\"btn btn-primary btn-block\">Solicitar nueva contraseña</button>
                  </div>
                  <!-- /.col -->
                </div>
            </form>
            <p class=\"mt-3 mb-1 text-center\">
            \t<a href=\"";
        // line 78
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 78, $this->source); })()), "html", null, true);
        echo "/login\" class=\"f_link\">Login</a>
            </p>
        </div>
        <!-- /.login-card-body -->
      </div>
    </div>
    <!-- /.login-box -->

    <!-- JQuery -->
    <script src=\"https://code.jquery.com/jquery-3.5.1.slim.min.js\" integrity=\"sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj\" crossorigin=\"anonymous\"></script>
    <!-- Bootstrap -->
    <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns\" crossorigin=\"anonymous\"></script>
    <!-- AdminLTE -->
    <script src=\"https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js\"></script>
    <!-- Commons -->
    <script src=\"";
        // line 93
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 93, $this->source); })()), "html", null, true);
        echo "/js/commons.js\"></script>
    <!-- Custom Theme -->
    <script src=\"";
        // line 95
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 95, $this->source); })()), "html", null, true);
        echo "/js/private.js\"></script>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "administration/access/recoveryPassword.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  187 => 95,  182 => 93,  164 => 78,  136 => 53,  129 => 48,  123 => 43,  120 => 42,  111 => 40,  106 => 39,  104 => 38,  98 => 36,  95 => 35,  92 => 34,  89 => 33,  86 => 32,  83 => 31,  80 => 30,  77 => 29,  74 => 28,  65 => 21,  56 => 15,  45 => 7,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "administration/access/recoveryPassword.twig", "/home/jasschos/public_html/resources/views/administration/access/recoveryPassword.twig");
    }
}
