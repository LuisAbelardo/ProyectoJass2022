<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /administration/transferencia/transferenciaNew.twig */
class __TwigTemplate_f39b8c8924c6a118df0656ffeafb3205ebee6cd1abd8e8318fd6b9c840540585 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content_main' => [$this, 'block_content_main'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "administration/templateAdministration.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["menuLItem"] = "transferencia";
        // line 3
        $this->parent = $this->loadTemplate("administration/templateAdministration.twig", "/administration/transferencia/transferenciaNew.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "
<div class=\"f_card\">
\t";
        // line 9
        echo "\t<form class=\"f_inputflat\" id=\"formNuevaTransferencia\" method=\"post\" action=\"";
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 9, $this->source); })()), "html", null, true);
        echo "/transferencia/create\">
\t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t<div class=\"f_cardheader\">
      \t\t\t\t<div class=\"\"> 
                    \t<i class=\"fas fa-exchange-alt mr-3\"></i>Nueva transferencia
                \t</div>
      \t\t\t</div>
      \t\t</div>
      \t\t<div class=\"col-12 pb-2 text-secondary\">
      \t\t\t<span>Utilice la transferencia interna para transferir de una cuenta a otra, 
      \t\t\t\t\tla aplicación escribirá dos registros: un egreso en la cuenta de origen y un ingreso en la cuenta de destino.
      \t\t\t\t\tSe utilizará la misma cantidad y fecha para esta transacción.</span>
      \t\t</div>
      \t</div><!-- /.card-header -->
      \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t";
        // line 29
        echo "                ";
        $context["classAlert"] = "";
        // line 30
        echo "                ";
        if (twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 30, $this->source); })()))) {
            // line 31
            echo "                \t";
            $context["classAlert"] = "d-none";
            // line 32
            echo "                ";
        } elseif ((((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 32, $this->source); })()) >= 200) && ((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 32, $this->source); })()) < 300))) {
            // line 33
            echo "                    ";
            $context["classAlert"] = "alert-success";
            // line 34
            echo "                ";
        } elseif (((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 34, $this->source); })()) >= 400)) {
            // line 35
            echo "                    ";
            $context["classAlert"] = "alert-danger";
            // line 36
            echo "                ";
        }
        // line 37
        echo "      \t\t\t<div class=\"alert ";
        echo twig_escape_filter($this->env, (isset($context["classAlert"]) || array_key_exists("classAlert", $context) ? $context["classAlert"] : (function () { throw new RuntimeError('Variable "classAlert" does not exist.', 37, $this->source); })()), "html", null, true);
        echo " alert-dismissible fade show\" id=\"f_alertsContainer\" role=\"alert\">
                 \t<ul class=\"mb-0\" id=\"f_alertsUl\">
                 \t\t";
        // line 39
        if ( !twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 39, $this->source); })()))) {
            // line 40
            echo "                          ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 40, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["msj"]) {
                // line 41
                echo "                            <li>";
                echo twig_escape_filter($this->env, $context["msj"], "html", null, true);
                echo "</li>
                          ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 43
            echo "                        ";
        }
        // line 44
        echo "                 \t</ul>
                 \t<button type=\"button\" class=\"close\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\" id=\"f_alertsDismiss\">
                 \t\t<span aria-hidden=\"true\">&times;</span>
                 \t</button>
                </div>";
        // line 49
        echo "      \t\t</div>
      \t</div>
      \t
  
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t<div class=\"f_divwithbartop f_divwithbarbottom\">
                    
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpMonto\">Monto</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                            ";
        // line 60
        $context["monto"] = "";
        // line 61
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevaTransferencia", [], "any", true, true, false, 61)) {
            // line 62
            echo "                        \t    ";
            $context["monto"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 62, $this->source); })()), "formNuevaTransferencia", [], "any", false, false, false, 62), "monto", [], "any", false, false, false, 62);
        }
        // line 63
        echo "                        \t<div style=\"background-color:#b9ceac\" class=\"d-inline-block\">
                        \t\t<span class=\"pl-1\">S/. </span>
                        \t\t<input type=\"text\" class=\"f_minwidth100\" id=\"inpMonto\" name=\"monto\" required 
                        \t\t\tstyle=\"background-color:#b9ceac\" value='";
        // line 66
        echo twig_escape_filter($this->env, (isset($context["monto"]) || array_key_exists("monto", $context) ? $context["monto"] : (function () { throw new RuntimeError('Variable "monto" does not exist.', 66, $this->source); })()), "html", null, true);
        echo "'>
                        \t</div>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2  f_fieldrequired\" for=\"cmbCajaEmisor\">De</label>
                        <div class=\"col-12 col-md-9\">
                            <select name=\"cajaEmisor\" class=\"f_minwidth200\" id=\"cmbCajaEmisor\" required>
                            \t<option value=\"-1\" class=\"f_opacitymedium\"></option>
                                ";
        // line 75
        $context["selectedCajaEmisor"] = false;
        // line 76
        echo "                                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 76, $this->source); })()), "cajasEmisor", [], "any", false, false, false, 76));
        foreach ($context['_seq'] as $context["_key"] => $context["cajaEmisor"]) {
            // line 77
            echo "                                \t<option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["cajaEmisor"], "CAJ_CODIGO", [], "any", false, false, false, 77), "html", null, true);
            echo "\"
                            \t\t\t\t";
            // line 78
            if ((( !(isset($context["selectedCajaEmisor"]) || array_key_exists("selectedCajaEmisor", $context) ? $context["selectedCajaEmisor"] : (function () { throw new RuntimeError('Variable "selectedCajaEmisor" does not exist.', 78, $this->source); })()) && twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevaTransferencia", [], "any", true, true, false, 78)) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source,             // line 79
(isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 79, $this->source); })()), "formNuevaTransferencia", [], "any", false, false, false, 79), "cajaEmisor", [], "any", false, false, false, 79) == twig_get_attribute($this->env, $this->source, $context["cajaEmisor"], "CAJ_CODIGO", [], "any", false, false, false, 79)))) {
                // line 80
                echo "                            \t\t\t\t\t";
                echo "selected";
                $context["selectedCajaEmisor"] = true;
                // line 81
                echo "                                            ";
            }
            echo ">
                        \t\t\t\t";
            // line 82
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["cajaEmisor"], "CAJ_NOMBRE", [], "any", false, false, false, 82), "html", null, true);
            echo "
                    \t\t\t\t</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cajaEmisor'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 85
        echo "                            </select>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2  f_fieldrequired\" for=\"cmbCajaReceptor\">Hacia</label>
                        <div class=\"col-12 col-md-9\">
                            <select name=\"cajaReceptor\" class=\"f_minwidth200\" id=\"cmbCajaReceptor\" required>
                            \t<option value=\"-1\" class=\"f_opacitymedium\"></option>
                                ";
        // line 93
        $context["selectedCajaReceptor"] = false;
        // line 94
        echo "                                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 94, $this->source); })()), "cajasReceptor", [], "any", false, false, false, 94));
        foreach ($context['_seq'] as $context["_key"] => $context["cajaReceptor"]) {
            // line 95
            echo "                                \t<option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["cajaReceptor"], "CAJ_CODIGO", [], "any", false, false, false, 95), "html", null, true);
            echo "\"
                            \t\t\t\t";
            // line 96
            if ((( !(isset($context["selectedCajaReceptor"]) || array_key_exists("selectedCajaReceptor", $context) ? $context["selectedCajaReceptor"] : (function () { throw new RuntimeError('Variable "selectedCajaReceptor" does not exist.', 96, $this->source); })()) && twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevaTransferencia", [], "any", true, true, false, 96)) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source,             // line 97
(isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 97, $this->source); })()), "formNuevaTransferencia", [], "any", false, false, false, 97), "cajaReceptor", [], "any", false, false, false, 97) == twig_get_attribute($this->env, $this->source, $context["cajaReceptor"], "CAJ_CODIGO", [], "any", false, false, false, 97)))) {
                // line 98
                echo "                            \t\t\t\t\t";
                echo "selected";
                $context["selectedCajaReceptor"] = true;
                // line 99
                echo "                                            ";
            }
            echo ">
                        \t\t\t\t";
            // line 100
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["cajaReceptor"], "CAJ_NOMBRE", [], "any", false, false, false, 100), "html", null, true);
            echo "
                    \t\t\t\t</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cajaReceptor'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 103
        echo "                            </select>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpDescripcion\">Descripción</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 109
        $context["descripcion"] = "";
        // line 110
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevaTransferencia", [], "any", false, true, false, 110), "descripcion", [], "any", true, true, false, 110)) {
            // line 111
            echo "                        \t    ";
            $context["descripcion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 111, $this->source); })()), "formNuevaTransferencia", [], "any", false, false, false, 111), "descripcion", [], "any", false, false, false, 111);
        }
        // line 112
        echo "                        \t<textarea class=\"f_minwidth400\" id=\"inpDescripcion\" rows=\"2\" maxlength=\"256\" 
                        \t\t\t\tname=\"descripcion\" required>";
        // line 113
        echo twig_escape_filter($this->env, (isset($context["descripcion"]) || array_key_exists("descripcion", $context) ? $context["descripcion"] : (function () { throw new RuntimeError('Variable "descripcion" does not exist.', 113, $this->source); })()), "html", null, true);
        echo "</textarea>
                        </div>
                    </div>
                    
      \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-body -->
  \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t<div class=\"f_cardfooter f_cardfooteractions text-center\">
        \t\t\t<button type=\"submit\" class=\"f_button f_buttonaction\">Crear</button>
    \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-footer -->
  \t
  \t</form>";
        // line 130
        echo "  
</div><!-- /.card -->

";
    }

    // line 135
    public function block_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 136
        echo "
    ";
        // line 137
        $this->displayParentBlock("scripts", $context, $blocks);
        echo "
  
\t<script type=\"text/javascript\">
\t\t\$('#formNuevaTransferencia').keypress(function(e) {
            if (e.which == 13) {
                return false;
            }
        });
        
        f_select2(\"#cmbCajaEmisor\");
        f_select2(\"#cmbCajaReceptor\");
        
\t</script>
";
    }

    public function getTemplateName()
    {
        return "/administration/transferencia/transferenciaNew.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  304 => 137,  301 => 136,  297 => 135,  290 => 130,  271 => 113,  268 => 112,  264 => 111,  261 => 110,  259 => 109,  251 => 103,  242 => 100,  237 => 99,  233 => 98,  231 => 97,  230 => 96,  225 => 95,  220 => 94,  218 => 93,  208 => 85,  199 => 82,  194 => 81,  190 => 80,  188 => 79,  187 => 78,  182 => 77,  177 => 76,  175 => 75,  163 => 66,  158 => 63,  154 => 62,  151 => 61,  149 => 60,  136 => 49,  130 => 44,  127 => 43,  118 => 41,  113 => 40,  111 => 39,  105 => 37,  102 => 36,  99 => 35,  96 => 34,  93 => 33,  90 => 32,  87 => 31,  84 => 30,  81 => 29,  58 => 9,  54 => 6,  50 => 5,  45 => 3,  43 => 1,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("", "/administration/transferencia/transferenciaNew.twig", "/home/jasschos/public_html/resources/views/administration/transferencia/transferenciaNew.twig");
    }
}
