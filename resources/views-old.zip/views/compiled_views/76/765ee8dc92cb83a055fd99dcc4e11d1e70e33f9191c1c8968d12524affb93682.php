<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /administration/servicioadicionalrcb/servicioAdicionalRcbNew.twig */
class __TwigTemplate_f3c8f4666e94c404b26e5c5fab2b1f5c55d7ce87abbb96ce1472bdf1dfd68d4e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content_main' => [$this, 'block_content_main'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "administration/templateAdministration.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        list($context["menuLItem"], $context["menuLLink"]) =         ["montoadicionalrecibo", "nuevo"];
        // line 3
        $this->parent = $this->loadTemplate("administration/templateAdministration.twig", "/administration/servicioadicionalrcb/servicioAdicionalRcbNew.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "
<div class=\"f_card\">
\t";
        // line 9
        echo "\t<form class=\"f_inputflat\" id=\"formNuevoServAdicionalRcb\" method=\"post\" action=\"";
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 9, $this->source); })()), "html", null, true);
        echo "/montoadicionalrecibo/create\">
\t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t<div class=\"f_cardheader\">
      \t\t\t\t<div class=\"\"> 
                    \t<i class=\"fas fa-file-invoice-dollar mr-3\"></i>Nuevo monto para adicionar a recibo
                \t</div>
      \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-header -->
      \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t";
        // line 24
        echo "                ";
        $context["classAlert"] = "";
        // line 25
        echo "                ";
        if (twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 25, $this->source); })()))) {
            // line 26
            echo "                \t";
            $context["classAlert"] = "d-none";
            // line 27
            echo "                ";
        } elseif ((((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) >= 200) && ((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) < 300))) {
            // line 28
            echo "                    ";
            $context["classAlert"] = "alert-success";
            // line 29
            echo "                ";
        } elseif (((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 29, $this->source); })()) >= 400)) {
            // line 30
            echo "                    ";
            $context["classAlert"] = "alert-danger";
            // line 31
            echo "                ";
        }
        // line 32
        echo "      \t\t\t<div class=\"alert ";
        echo twig_escape_filter($this->env, (isset($context["classAlert"]) || array_key_exists("classAlert", $context) ? $context["classAlert"] : (function () { throw new RuntimeError('Variable "classAlert" does not exist.', 32, $this->source); })()), "html", null, true);
        echo " alert-dismissible fade show\" id=\"f_alertsContainer\" role=\"alert\">
                 \t<ul class=\"mb-0\" id=\"f_alertsUl\">
                 \t\t";
        // line 34
        if ( !twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 34, $this->source); })()))) {
            // line 35
            echo "                          ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 35, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["msj"]) {
                // line 36
                echo "                            <li>";
                echo twig_escape_filter($this->env, $context["msj"], "html", null, true);
                echo "</li>
                          ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "                        ";
        }
        // line 39
        echo "                 \t</ul>
                 \t<button type=\"button\" class=\"close\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\" id=\"f_alertsDismiss\">
                 \t\t<span aria-hidden=\"true\">&times;</span>
                 \t</button>
                </div>";
        // line 44
        echo "      \t\t</div>
      \t</div>
      \t
  
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t
      \t\t\t<div class=\"f_divwithbartop f_divwithbarbottom\">
      \t\t\t\t<div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpCosto\">Monto</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                            ";
        // line 55
        $context["costo"] = "";
        // line 56
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoServAdicionalRcb", [], "any", true, true, false, 56)) {
            // line 57
            echo "                        \t    ";
            $context["costo"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 57, $this->source); })()), "formNuevoServAdicionalRcb", [], "any", false, false, false, 57), "costo", [], "any", false, false, false, 57);
        }
        // line 58
        echo "                        \t<div style=\"background-color:#b9ceac\" class=\"d-inline-block\">
                        \t\t<span class=\"pl-1\">S/. </span>
                        \t\t<input type=\"text\" class=\"f_minwidth100\" id=\"inpCosto\" name=\"costo\" required 
                        \t\t\tstyle=\"background-color:#b9ceac\" value='";
        // line 61
        echo twig_escape_filter($this->env, (isset($context["costo"]) || array_key_exists("costo", $context) ? $context["costo"] : (function () { throw new RuntimeError('Variable "costo" does not exist.', 61, $this->source); })()), "html", null, true);
        echo "'>
                        \t</div>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpContrato\">Codigo contrato</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 68
        $context["contrato"] = "";
        // line 69
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoServAdicionalRcb", [], "any", true, true, false, 69)) {
            // line 70
            echo "                        \t    ";
            $context["contrato"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 70, $this->source); })()), "formNuevoServAdicionalRcb", [], "any", false, false, false, 70), "contrato", [], "any", false, false, false, 70);
        }
        // line 71
        echo "                        \t<input type=\"text\" class=\"f_minwidth150\" id=\"inpContrato\" name=\"contrato\" required value='";
        echo twig_escape_filter($this->env, (isset($context["contrato"]) || array_key_exists("contrato", $context) ? $context["contrato"] : (function () { throw new RuntimeError('Variable "contrato" does not exist.', 71, $this->source); })()), "html", null, true);
        echo "'>
                \t\t\t<button type=\"button\" class=\"f_btnflat\" name=\"btnBuscarContrato\" id=\"btnBuscarContrato\">
                \t\t\t\t<span class=\"fas fa-search\"></span>
            \t\t\t\t</button>
                \t\t\t<span><i class=\"fas fa-spinner f_classforrotatespinner d-none\" id=\"spinnerBuscarContrato\"></i></span>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_field\" for=\"inpPredioCodigo\">Predio Ref.</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t<input type=\"text\" class=\"f_minwidth400\" id=\"inpPredioCodigo\" name=\"predioCodigo\" disabled value=''>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_field\" for=\"inpPredioCalle\">Predio calle</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t<input type=\"text\" class=\"f_minwidth400\" id=\"inpPredioCalle\" name=\"predioCalle\" disabled value=''>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_field\" for=\"inpPredioDireccion\">Predio dirección</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t<input type=\"text\" class=\"f_minwidth400\" id=\"inpPredioDireccion\" name=\"predioDireccion\" disabled value=''>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_field\" for=\"inpClienteDocumento\">Cliente DNI / RUC</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t<input type=\"text\" class=\"f_minwidth150\" id=\"inpClienteDocumento\" name=\"clienteDocumento\" disabled value=''>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_field\" for=\"inpClienteNombre\">Cliente nombre</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t<input type=\"text\" class=\"f_minwidth400\" id=\"inpClienteNombre\" name=\"clienteNombre\" disabled value=''>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpDescripcion\">Descripción</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 111
        $context["descripcion"] = "";
        // line 112
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoServAdicionalRcb", [], "any", false, true, false, 112), "descripcion", [], "any", true, true, false, 112)) {
            // line 113
            echo "                        \t    ";
            $context["descripcion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 113, $this->source); })()), "formNuevoServAdicionalRcb", [], "any", false, false, false, 113), "descripcion", [], "any", false, false, false, 113);
        }
        // line 114
        echo "                        \t<textarea class=\"f_minwidth400\" id=\"inpDescripcion\" rows=\"2\" maxlength=\"256\" 
                        \t\t\t\tname=\"descripcion\" required>";
        // line 115
        echo twig_escape_filter($this->env, (isset($context["descripcion"]) || array_key_exists("descripcion", $context) ? $context["descripcion"] : (function () { throw new RuntimeError('Variable "descripcion" does not exist.', 115, $this->source); })()), "html", null, true);
        echo "</textarea>
                        </div>
                    </div>
      \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-body -->
  \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t<div class=\"f_cardfooter f_cardfooteractions text-center\">
        \t\t\t<button type=\"submit\" class=\"f_button f_buttonaction\">Guardar</button>
        \t\t\t<a href=\"";
        // line 126
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 126, $this->source); })()), "html", null, true);
        echo "/montoadicionalrecibo/lista\" class=\"f_linkbtn f_linkbtnaction\">Cancelar</a>
    \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-footer -->
  \t
  \t</form>";
        // line 132
        echo "  
</div><!-- /.card -->

";
    }

    // line 137
    public function block_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 138
        echo "
    ";
        // line 139
        $this->displayParentBlock("scripts", $context, $blocks);
        echo "
  
\t<script type=\"text/javascript\">
\t\t\$('#formNuevoServAdicionalRcb').keypress(function(e) {
            if (e.which == 13) {
                return false;
            }
        });
        
        \$(\"#btnBuscarContrato\").click(function(){
        
        \t\$(\"#inpPredioCodigo\").val(\"\");
        \t\$(\"#inpPredioCalle\").val(\"\");
\t\t\t\$(\"#inpPredioDireccion\").val(\"\");
\t\t\t\$(\"#inpClienteDocumento\").val(\"\");
\t\t\t\$(\"#inpClienteNombre\").val(\"\");
        \t
        \t\$(\"#inpContrato\").val(\$(\"#inpContrato\").val().trim());
        \tvar inpContrato = \$(\"#inpContrato\").val();
        \t
        \tif(inpContrato != \"\"){
        \t
        \t\tvar spinnerBuscarContrato = \$(\"#spinnerBuscarContrato\");
        \t\tspinnerBuscarContrato.removeClass(\"d-none\");
        \t
        \t\t\$.ajax({
                    method: \"GET\",
                    url: \"";
        // line 166
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 166, $this->source); })()), "html", null, true);
        echo "/contrato/detalle/json/\"+inpContrato,
                    dataType: \"json\",
                    complete: function(){
                    \tspinnerBuscarContrato.addClass(\"d-none\");
                    },
        \t\t\terror: function(jqXHR ){
        \t\t\t\tvar msj = \"\";
        \t\t\t\tif(jqXHR.status == 404){
        \t\t\t\t\tmsj = \"No se encontro el contrato solicitado\";
        \t\t\t\t\tconsole.log(msj);
        \t\t\t\t}else{
        \t\t\t\t\tmsj = \"Ocurrio un error inesperado, vuelva a intentarlo\";
        \t\t\t\t\tconsole.log(msj);
        \t\t\t\t}
        \t\t\t\t\$(document).Toasts('create', {
                            \tclass: 'bg-danger',
                                title: 'Respuesta de busqueda',
                                position: 'topRight',
                                autohide: true,
       \t\t\t\t\t\t\tdelay: 4000,
                                body: msj
                            })
        \t\t\t},
        \t\t\tsuccess: function(respons){
        \t\t\t\t\$(\"#inpPredioCodigo\").val(respons.data.predio.codigo);
        \t\t\t\t\$(\"#inpPredioCalle\").val(respons.data.calle.nombre);
        \t\t\t\t\$(\"#inpPredioDireccion\").val(respons.data.predio.direccion);
        \t\t\t\t\$(\"#inpClienteDocumento\").val(respons.data.cliente.documento);
        \t\t\t\t\$(\"#inpClienteNombre\").val(respons.data.cliente.nombre);
        \t\t\t}
                });
        \t}
        });
\t</script>
";
    }

    public function getTemplateName()
    {
        return "/administration/servicioadicionalrcb/servicioAdicionalRcbNew.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  299 => 166,  269 => 139,  266 => 138,  262 => 137,  255 => 132,  247 => 126,  233 => 115,  230 => 114,  226 => 113,  223 => 112,  221 => 111,  177 => 71,  173 => 70,  170 => 69,  168 => 68,  158 => 61,  153 => 58,  149 => 57,  146 => 56,  144 => 55,  131 => 44,  125 => 39,  122 => 38,  113 => 36,  108 => 35,  106 => 34,  100 => 32,  97 => 31,  94 => 30,  91 => 29,  88 => 28,  85 => 27,  82 => 26,  79 => 25,  76 => 24,  58 => 9,  54 => 6,  50 => 5,  45 => 3,  43 => 1,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("", "/administration/servicioadicionalrcb/servicioAdicionalRcbNew.twig", "/home/jasschos/public_html/resources/views/administration/servicioadicionalrcb/servicioAdicionalRcbNew.twig");
    }
}
