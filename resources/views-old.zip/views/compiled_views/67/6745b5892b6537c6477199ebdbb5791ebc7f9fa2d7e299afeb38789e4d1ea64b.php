<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /administration/contrato/contratoEdit.twig */
class __TwigTemplate_92bf0fc47fac0191ee32dc76c05e1907cf269b693ad38578370bdb9721c78ea5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content_main' => [$this, 'block_content_main'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "administration/templateAdministration.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["menuLItem"] = "contrato";
        // line 3
        $this->parent = $this->loadTemplate("administration/templateAdministration.twig", "/administration/contrato/contratoEdit.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "
<div class=\"f_card\">
\t";
        // line 9
        echo "\t<form class=\"f_inputflat\" id=\"formEditarPredio\" method=\"post\" action=\"";
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 9, $this->source); })()), "html", null, true);
        echo "/contrato/update\">
\t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t<div class=\"f_cardheader\">
      \t\t\t\t<div class=\"\"> 
                    \t<i class=\"fas fa-file-contract mr-3\"></i>Editar contrato
                \t</div>
      \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-header -->
      \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t";
        // line 24
        echo "                ";
        $context["classAlert"] = "";
        // line 25
        echo "                ";
        if (twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 25, $this->source); })()))) {
            // line 26
            echo "                \t";
            $context["classAlert"] = "d-none";
            // line 27
            echo "                ";
        } elseif ((((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) >= 200) && ((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) < 300))) {
            // line 28
            echo "                    ";
            $context["classAlert"] = "alert-success";
            // line 29
            echo "                ";
        } elseif (((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 29, $this->source); })()) >= 400)) {
            // line 30
            echo "                    ";
            $context["classAlert"] = "alert-danger";
            // line 31
            echo "                ";
        }
        // line 32
        echo "      \t\t\t<div class=\"alert ";
        echo twig_escape_filter($this->env, (isset($context["classAlert"]) || array_key_exists("classAlert", $context) ? $context["classAlert"] : (function () { throw new RuntimeError('Variable "classAlert" does not exist.', 32, $this->source); })()), "html", null, true);
        echo " alert-dismissible fade show\" id=\"f_alertsContainer\" role=\"alert\">
                 \t<ul class=\"mb-0\" id=\"f_alertsUl\">
                 \t\t";
        // line 34
        if ( !twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 34, $this->source); })()))) {
            // line 35
            echo "                          ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 35, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["msj"]) {
                // line 36
                echo "                            <li>";
                echo twig_escape_filter($this->env, $context["msj"], "html", null, true);
                echo "</li>
                          ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "                        ";
        }
        // line 39
        echo "                 \t</ul>
                 \t<button type=\"button\" class=\"close\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\" id=\"f_alertsDismiss\">
                 \t\t<span aria-hidden=\"true\">&times;</span>
                 \t</button>
                </div>";
        // line 44
        echo "      \t\t</div>
      \t</div>
      \t
  \t\t<div class=\"f_divwithbartop f_divwithbarbottom\">
          \t<div class=\"row\">
          \t\t<div class=\"col-6\">
      \t\t\t\t<div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 f_field\">Ref.</label>
                        <div class=\"col-12 col-md-9\">
                        \t";
        // line 53
        $context["codigoContrato"] = "";
        // line 54
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 54)) {
            $context["codigoContrato"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 54, $this->source); })()), "contrato", [], "any", false, false, false, 54), "CTO_CODIGO", [], "any", false, false, false, 54);
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 54, $this->source); })()), "contrato", [], "any", false, false, false, 54), "CTO_CODIGO", [], "any", false, false, false, 54), "html", null, true);
            echo "
                        \t";
        } elseif (twig_get_attribute($this->env, $this->source,         // line 55
($context["data"] ?? null), "formEditarContrato", [], "any", true, true, false, 55)) {
            // line 56
            echo "                        \t    ";
            $context["codigoContrato"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 56, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 56), "codigo", [], "any", false, false, false, 56);
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 56, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 56), "codigo", [], "any", false, false, false, 56), "html", null, true);
        }
        // line 57
        echo "                        \t<input type=\"hidden\" class=\"f_minwidth300\" id=\"inpCodigo\" name=\"codigo\" value='";
        echo twig_escape_filter($this->env, (isset($context["codigoContrato"]) || array_key_exists("codigoContrato", $context) ? $context["codigoContrato"] : (function () { throw new RuntimeError('Variable "codigoContrato" does not exist.', 57, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 f_field\" for=\"inpPredio\">Código de predio</label>
                        <div class=\"col-12 col-md-9\">
                        \t";
        // line 63
        $context["predioCodigo"] = "";
        // line 64
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "predio", [], "any", true, true, false, 64)) {
            $context["predioCodigo"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 64, $this->source); })()), "predio", [], "any", false, false, false, 64), "PRE_CODIGO", [], "any", false, false, false, 64);
            // line 65
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarContrato", [], "any", true, true, false, 65)) {
            $context["predioCodigo"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 65, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 65), "predioCodigo", [], "any", false, false, false, 65);
        }
        // line 66
        echo "                        \t<input type=\"text\" class=\"f_minwidth150\" id=\"inpPredio\" disabled value='";
        echo twig_escape_filter($this->env, (isset($context["predioCodigo"]) || array_key_exists("predioCodigo", $context) ? $context["predioCodigo"] : (function () { throw new RuntimeError('Variable "predioCodigo" does not exist.', 66, $this->source); })()), "html", null, true);
        echo "'>
                        \t<input type=\"hidden\" name=\"predioCodigo\" value='";
        // line 67
        echo twig_escape_filter($this->env, (isset($context["predioCodigo"]) || array_key_exists("predioCodigo", $context) ? $context["predioCodigo"] : (function () { throw new RuntimeError('Variable "predioCodigo" does not exist.', 67, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 f_field\" for=\"inpPredioCalle\">Predio calle</label>
                        <div class=\"col-12 col-md-9\">
                        \t";
        // line 73
        $context["predioCalle"] = "";
        // line 74
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "calle", [], "any", true, true, false, 74)) {
            $context["predioCalle"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 74, $this->source); })()), "calle", [], "any", false, false, false, 74), "CAL_NOMBRE", [], "any", false, false, false, 74);
            // line 75
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarContrato", [], "any", true, true, false, 75)) {
            $context["predioCalle"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 75, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 75), "predioCalle", [], "any", false, false, false, 75);
        }
        // line 76
        echo "                        \t<input type=\"text\" class=\"f_minwidth400\" id=\"inpPredioCalle\" disabled value='";
        echo twig_escape_filter($this->env, (isset($context["predioCalle"]) || array_key_exists("predioCalle", $context) ? $context["predioCalle"] : (function () { throw new RuntimeError('Variable "predioCalle" does not exist.', 76, $this->source); })()), "html", null, true);
        echo "'>
                        \t<input type=\"hidden\" name=\"predioCalle\" value='";
        // line 77
        echo twig_escape_filter($this->env, (isset($context["predioCalle"]) || array_key_exists("predioCalle", $context) ? $context["predioCalle"] : (function () { throw new RuntimeError('Variable "predioCalle" does not exist.', 77, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 f_field\" for=\"inpPredioDireccion\">Predio dirección</label>
                        <div class=\"col-12 col-md-9\">
                        \t";
        // line 83
        $context["predioDireccion"] = "";
        // line 84
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "predio", [], "any", true, true, false, 84)) {
            $context["predioDireccion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 84, $this->source); })()), "predio", [], "any", false, false, false, 84), "PRE_DIRECCION", [], "any", false, false, false, 84);
            // line 85
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarContrato", [], "any", true, true, false, 85)) {
            // line 86
            echo "                        \t    ";
            $context["predioDireccion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 86, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 86), "predioDireccion", [], "any", false, false, false, 86);
        }
        // line 87
        echo "                        \t<input type=\"text\" class=\"f_minwidth400\" id=\"inpPredioDireccion\" disabled value='";
        echo twig_escape_filter($this->env, (isset($context["predioDireccion"]) || array_key_exists("predioDireccion", $context) ? $context["predioDireccion"] : (function () { throw new RuntimeError('Variable "predioDireccion" does not exist.', 87, $this->source); })()), "html", null, true);
        echo "'>
                        \t<input type=\"hidden\" name=\"predioDireccion\" value='";
        // line 88
        echo twig_escape_filter($this->env, (isset($context["predioDireccion"]) || array_key_exists("predioDireccion", $context) ? $context["predioDireccion"] : (function () { throw new RuntimeError('Variable "predioDireccion" does not exist.', 88, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 f_field\" for=\"inpClienteDocumento\">Cliente DNI / RUC</label>
                        <div class=\"col-12 col-md-9\">
                        \t";
        // line 94
        $context["clienteDocumento"] = "";
        // line 95
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 95)) {
            $context["clienteDocumento"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 95, $this->source); })()), "cliente", [], "any", false, false, false, 95), "CLI_DOCUMENTO", [], "any", false, false, false, 95);
            // line 96
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarContrato", [], "any", true, true, false, 96)) {
            // line 97
            echo "                        \t    ";
            $context["clienteDocumento"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 97, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 97), "clienteDocumento", [], "any", false, false, false, 97);
        }
        // line 98
        echo "                        \t<input type=\"text\" class=\"f_minwidth150\" id=\"inpClienteDocumento\" disabled value='";
        echo twig_escape_filter($this->env, (isset($context["clienteDocumento"]) || array_key_exists("clienteDocumento", $context) ? $context["clienteDocumento"] : (function () { throw new RuntimeError('Variable "clienteDocumento" does not exist.', 98, $this->source); })()), "html", null, true);
        echo "'>
                        \t<input type=\"hidden\" name=\"clienteDocumento\" value='";
        // line 99
        echo twig_escape_filter($this->env, (isset($context["clienteDocumento"]) || array_key_exists("clienteDocumento", $context) ? $context["clienteDocumento"] : (function () { throw new RuntimeError('Variable "clienteDocumento" does not exist.', 99, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 f_field\" for=\"inpClienteNombre\">Cliente nombre</label>
                        <div class=\"col-12 col-md-9\">
                        \t";
        // line 105
        $context["clienteNombre"] = "";
        // line 106
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 106)) {
            $context["clienteNombre"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 106, $this->source); })()), "cliente", [], "any", false, false, false, 106), "CLI_NOMBRES", [], "any", false, false, false, 106);
            // line 107
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarContrato", [], "any", true, true, false, 107)) {
            // line 108
            echo "                        \t    ";
            $context["clienteNombre"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 108, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 108), "clienteNombre", [], "any", false, false, false, 108);
        }
        // line 109
        echo "                        \t<input type=\"text\" class=\"f_minwidth400\" id=\"inpClienteNombre\" disabled value='";
        echo twig_escape_filter($this->env, (isset($context["clienteNombre"]) || array_key_exists("clienteNombre", $context) ? $context["clienteNombre"] : (function () { throw new RuntimeError('Variable "clienteNombre" does not exist.', 109, $this->source); })()), "html", null, true);
        echo "'>
                        \t<input type=\"hidden\" name=\"clienteNombre\" value='";
        // line 110
        echo twig_escape_filter($this->env, (isset($context["clienteNombre"]) || array_key_exists("clienteNombre", $context) ? $context["clienteNombre"] : (function () { throw new RuntimeError('Variable "clienteNombre" does not exist.', 110, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    ";
        // line 114
        echo "                    <div class=\"form-group row d-none\">
                    \t<label class=\"col-12 col-md-3 f_field\" for=\"inpEstado\">Old Estate</label>
                        <div class=\"col-12 col-md-9\">
                    \t\t";
        // line 117
        $context["estado"] = "";
        // line 118
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 118)) {
            $context["estado"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 118, $this->source); })()), "contrato", [], "any", false, false, false, 118), "CTO_ESTADO", [], "any", false, false, false, 118);
            // line 119
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarContrato", [], "any", true, true, false, 119)) {
            $context["estado"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 119, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 119), "estado", [], "any", false, false, false, 119);
        }
        // line 120
        echo "                        \t<input type=\"hidden\" class=\"f_minwidth300\" id=\"inpEstado\" name=\"estado\" value='";
        echo twig_escape_filter($this->env, (isset($context["estado"]) || array_key_exists("estado", $context) ? $context["estado"] : (function () { throw new RuntimeError('Variable "estado" does not exist.', 120, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>";
        // line 123
        echo "                    
                    ";
        // line 124
        if ((((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 124) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 124, $this->source); })()), "contrato", [], "any", false, false, false, 124), "CTO_ESTADO", [], "any", false, false, false, 124) == 0)) || (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 124) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 124, $this->source); })()), "contrato", [], "any", false, false, false, 124), "CTO_ESTADO", [], "any", false, false, false, 124) == 5))) || (twig_get_attribute($this->env, $this->source,         // line 125
($context["data"] ?? null), "formEditarContrato", [], "any", true, true, false, 125) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 125, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 125), "estado", [], "any", false, false, false, 125) == 0)))) {
            // line 126
            echo "                    <div class=\"form-group row\">
                    \t<span class=\"col-12 col-md-3 f_field\" for=\"chkContratoInicio\">Estado</span>
                        <div class=\"col-12 col-md-9\">
                        \t";
            // line 129
            $context["chkEstado"] = "";
            // line 130
            echo "                        \t";
            if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarContrato", [], "any", false, true, false, 130), "estadoNuevo", [], "any", true, true, false, 130) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 130, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 130), "estadoNuevo", [], "any", false, false, false, 130) == 1))) {
                // line 131
                echo "                        \t    ";
                $context["chkEstado"] = "checked";
            }
            // line 132
            echo "                        \t<input type=\"checkbox\" id=\"chkContratoInicio\" name=\"estadoNuevo\" ";
            echo twig_escape_filter($this->env, (isset($context["chkEstado"]) || array_key_exists("chkEstado", $context) ? $context["chkEstado"] : (function () { throw new RuntimeError('Variable "chkEstado" does not exist.', 132, $this->source); })()), "html", null, true);
            echo " value=\"1\">
                        \t<label class=\"f_field\" for=\"chkContratoInicio\">Contrato activo</label>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 f_field\" for=\"inpFechaInicio\">Fecha Inicio</label>
                        <div class=\"col-12 col-md-9\">
                    \t\t";
            // line 139
            $context["fechaInicio"] = "";
            // line 140
            echo "                        \t";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 140)) {
                $context["fechaInicio"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 140, $this->source); })()), "contrato", [], "any", false, false, false, 140), "CTO_FECHA_INICIO", [], "any", false, false, false, 140);
                // line 141
                echo "                        \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarContrato", [], "any", false, true, false, 141), "fechaInicio", [], "any", true, true, false, 141)) {
                // line 142
                echo "                        \t    ";
                $context["fechaInicio"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 142, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 142), "fechaInicio", [], "any", false, false, false, 142);
            }
            // line 143
            echo "                        \t<input type=\"date\" class=\"f_minwidth300\" id=\"inpFechaInicio\" name=\"fechaInicio\" value='";
            echo twig_escape_filter($this->env, (isset($context["fechaInicio"]) || array_key_exists("fechaInicio", $context) ? $context["fechaInicio"] : (function () { throw new RuntimeError('Variable "fechaInicio" does not exist.', 143, $this->source); })()), "html", null, true);
            echo "'>
                        </div>
                    </div>
                    ";
        }
        // line 147
        echo "\t\t\t\t\t
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 f_field\" for=\"txaObservacion\">Observación</label>
                        <div class=\"col-12 col-md-9\">
                        \t";
        // line 151
        $context["observacion"] = "";
        // line 152
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 152)) {
            $context["observacion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 152, $this->source); })()), "contrato", [], "any", false, false, false, 152), "CTO_OBSERVACION", [], "any", false, false, false, 152);
            // line 153
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarContrato", [], "any", true, true, false, 153)) {
            $context["observacion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 153, $this->source); })()), "formEditarContrato", [], "any", false, false, false, 153), "observacion", [], "any", false, false, false, 153);
        }
        // line 154
        echo "                        \t<textarea class=\"f_minwidth400\" id=\"txaObservacion\" rows=\"2\" maxlength=\"256\" 
                        \t\tname=\"observacion\">";
        // line 155
        echo twig_escape_filter($this->env, (isset($context["observacion"]) || array_key_exists("observacion", $context) ? $context["observacion"] : (function () { throw new RuntimeError('Variable "observacion" does not exist.', 155, $this->source); })()), "html", null, true);
        echo "</textarea>
                        </div>
                    </div>
          \t\t</div>
          \t\t
          \t\t
          \t\t
          \t\t
          \t\t";
        // line 163
        $context["tieneAgua"] = false;
        // line 164
        echo "              \t";
        $context["tieneDesague"] = false;
        // line 165
        echo "              \t
              \t";
        // line 166
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "servicios", [], "any", true, true, false, 166)) {
            // line 167
            echo "              \t\t";
            $context["cantServicios"] = 0;
            // line 168
            echo "              \t    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 168, $this->source); })()), "servicios", [], "any", false, false, false, 168));
            foreach ($context['_seq'] as $context["_key"] => $context["servicio"]) {
                // line 169
                echo "              \t    \t";
                if ((twig_get_attribute($this->env, $this->source, $context["servicio"], "SRV_CODIGO", [], "any", false, false, false, 169) == 1)) {
                    $context["tieneAgua"] = true;
                    // line 170
                    echo "              \t    \t";
                } elseif ((twig_get_attribute($this->env, $this->source, $context["servicio"], "SRV_CODIGO", [], "any", false, false, false, 170) == 2)) {
                    $context["tieneDesague"] = true;
                }
                // line 171
                echo "              \t    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['servicio'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 172
            echo "              \t";
        }
        // line 173
        echo "          \t\t<div class=\"col-6\">
          \t\t\t";
        // line 175
        echo "                \t<div id=\"divNuevoContratoMasDetalles\">
                \t
                \t\t";
        // line 177
        if ((isset($context["tieneAgua"]) || array_key_exists("tieneAgua", $context) ? $context["tieneAgua"] : (function () { throw new RuntimeError('Variable "tieneAgua" does not exist.', 177, $this->source); })())) {
            // line 178
            echo "                        ";
            // line 179
            echo "                \t\t<div id=\"divNuevoContratoMasDetallesAgua\">
                    \t\t<h6 class=\"mb-4 text-bold\">Servicio de Agua</h6>
                    \t\t<div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"inpAguaFechaInstalacion\">Fecha de instalación</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 184
            $context["aguaFechaInstalacion"] = "";
            // line 185
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 185)) {
                $context["aguaFechaInstalacion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 185, $this->source); })()), "contrato", [], "any", false, false, false, 185), "CTO_AGU_FEC_INS", [], "any", false, false, false, 185);
                // line 186
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 186), "aguaFechaInstalacion", [], "any", true, true, false, 186)) {
                // line 187
                echo "                                \t    ";
                $context["aguaFechaInstalacion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 187, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 187), "aguaFechaInstalacion", [], "any", false, false, false, 187);
            }
            // line 188
            echo "                                \t<input type=\"date\" class=\"f_minwidth300\" id=\"inpAguaFechaInstalacion\" name=\"aguaFechaInstalacion\" 
                                \t\t\tvalue=\"";
            // line 189
            echo twig_escape_filter($this->env, (isset($context["aguaFechaInstalacion"]) || array_key_exists("aguaFechaInstalacion", $context) ? $context["aguaFechaInstalacion"] : (function () { throw new RuntimeError('Variable "aguaFechaInstalacion" does not exist.', 189, $this->source); })()), "html", null, true);
            echo "\">
                                </div>
                            </div>
                    \t\t<div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\">Característica de la conexion</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 195
            $context["aguaConexionCaracteristica"] = "";
            // line 196
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 196)) {
                $context["aguaConexionCaracteristica"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 196, $this->source); })()), "contrato", [], "any", false, false, false, 196), "CTO_AGU_CAR_CNX", [], "any", false, false, false, 196);
                // line 197
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 197), "aguaConexionCaracteristica", [], "any", true, true, false, 197)) {
                // line 198
                echo "                                \t    ";
                $context["aguaConexionCaracteristica"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 198, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 198), "aguaConexionCaracteristica", [], "any", false, false, false, 198);
            }
            // line 199
            echo "                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"aguaConexionCaracteristica\" 
                                        \t\tid=\"inpAguaConexionCaracteristicaSC\" value=\"sin caja\"
                                        \t\t";
            // line 202
            if (((isset($context["aguaConexionCaracteristica"]) || array_key_exists("aguaConexionCaracteristica", $context) ? $context["aguaConexionCaracteristica"] : (function () { throw new RuntimeError('Variable "aguaConexionCaracteristica" does not exist.', 202, $this->source); })()) == "sin caja")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAguaConexionCaracteristicaSC\">Sin caja</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"aguaConexionCaracteristica\" 
                                        \t\tid=\"inpAguaConexionCaracteristicaCC\" value=\"con caja\"
                                        \t\t";
            // line 208
            if (((isset($context["aguaConexionCaracteristica"]) || array_key_exists("aguaConexionCaracteristica", $context) ? $context["aguaConexionCaracteristica"] : (function () { throw new RuntimeError('Variable "aguaConexionCaracteristica" does not exist.', 208, $this->source); })()) == "con caja")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAguaConexionCaracteristicaCC\">Con caja</label>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\">Diametro de la conexion</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 216
            $context["aguaConexionDiametro"] = "";
            // line 217
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 217)) {
                $context["aguaConexionDiametro"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 217, $this->source); })()), "contrato", [], "any", false, false, false, 217), "CTO_AGU_DTO_CNX", [], "any", false, false, false, 217);
                // line 218
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 218), "aguaConexionDiametro", [], "any", true, true, false, 218)) {
                // line 219
                echo "                                \t    ";
                $context["aguaConexionDiametro"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 219, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 219), "aguaConexionDiametro", [], "any", false, false, false, 219);
            }
            // line 220
            echo "                                \t<div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"aguaConexionDiametro\" 
                                        \t\tid=\"inpAguaConexionDiametro1-2\" value=\"1/2\"
                                        \t\t";
            // line 223
            if (((isset($context["aguaConexionDiametro"]) || array_key_exists("aguaConexionDiametro", $context) ? $context["aguaConexionDiametro"] : (function () { throw new RuntimeError('Variable "aguaConexionDiametro" does not exist.', 223, $this->source); })()) == "1/2")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAguaConexionDiametro1-2\">1/2\"</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"aguaConexionDiametro\" 
                                        \t\tid=\"inpAguaConexionDiametro3-4\" value=\"3/4\"
                                        \t\t";
            // line 229
            if (((isset($context["aguaConexionDiametro"]) || array_key_exists("aguaConexionDiametro", $context) ? $context["aguaConexionDiametro"] : (function () { throw new RuntimeError('Variable "aguaConexionDiametro" does not exist.', 229, $this->source); })()) == "3/4")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAguaConexionDiametro3-4\">3/4\"</label>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\">Diametro de la red</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 237
            $context["aguaDiametroRed"] = "";
            // line 238
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 238)) {
                $context["aguaDiametroRed"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 238, $this->source); })()), "contrato", [], "any", false, false, false, 238), "CTO_AGU_DTO_RED", [], "any", false, false, false, 238);
                // line 239
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 239), "aguaDiametroRed", [], "any", true, true, false, 239)) {
                // line 240
                echo "                                \t    ";
                $context["aguaDiametroRed"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 240, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 240), "aguaDiametroRed", [], "any", false, false, false, 240);
            }
            // line 241
            echo "                                \t<div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"aguaDiametroRed\" 
                                        \t\tid=\"inpAguaDiametroRed2\" value=\"2\"
                                        \t\t";
            // line 244
            if (((isset($context["aguaDiametroRed"]) || array_key_exists("aguaDiametroRed", $context) ? $context["aguaDiametroRed"] : (function () { throw new RuntimeError('Variable "aguaDiametroRed" does not exist.', 244, $this->source); })()) == "2")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAguaDiametroRed2\">2\"</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"aguaDiametroRed\" 
                                        \t\tid=\"inpAguaDiametroRed3\" value=\"3\"
                                        \t\t";
            // line 250
            if (((isset($context["aguaDiametroRed"]) || array_key_exists("aguaDiametroRed", $context) ? $context["aguaDiametroRed"] : (function () { throw new RuntimeError('Variable "aguaDiametroRed" does not exist.', 250, $this->source); })()) == "3")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAguaDiametroRed3\">3\"</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"aguaDiametroRed\" 
                                        \t\tid=\"inpAguaDiametroRed4\" value=\"4\"
                                        \t\t";
            // line 256
            if (((isset($context["aguaDiametroRed"]) || array_key_exists("aguaDiametroRed", $context) ? $context["aguaDiametroRed"] : (function () { throw new RuntimeError('Variable "aguaDiametroRed" does not exist.', 256, $this->source); })()) == "4")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAguaDiametroRed4\">4\"</label>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\">Material de conexion</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 264
            $context["aguaMaterialConexion"] = "";
            // line 265
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 265)) {
                $context["aguaMaterialConexion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 265, $this->source); })()), "contrato", [], "any", false, false, false, 265), "CTO_AGU_MAT_CNX", [], "any", false, false, false, 265);
                // line 266
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 266), "aguaMaterialConexion", [], "any", true, true, false, 266)) {
                // line 267
                echo "                                \t    ";
                $context["aguaMaterialConexion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 267, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 267), "aguaMaterialConexion", [], "any", false, false, false, 267);
            }
            // line 268
            echo "                                \t<div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"aguaMaterialConexion\" 
                                        \t\tid=\"inpAguaMaterialConexionPVC\" value=\"pvc\"
                                        \t\t";
            // line 271
            if (((isset($context["aguaMaterialConexion"]) || array_key_exists("aguaMaterialConexion", $context) ? $context["aguaMaterialConexion"] : (function () { throw new RuntimeError('Variable "aguaMaterialConexion" does not exist.', 271, $this->source); })()) == "pvc")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAguaMaterialConexionPVC\">PVC</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"aguaMaterialConexion\" 
                                        \t\tid=\"inpAguaMaterialConexionF\" value=\"fierro\"
                                        \t\t";
            // line 277
            if (((isset($context["aguaMaterialConexion"]) || array_key_exists("aguaMaterialConexion", $context) ? $context["aguaMaterialConexion"] : (function () { throw new RuntimeError('Variable "aguaMaterialConexion" does not exist.', 277, $this->source); })()) == "fierro")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAguaMaterialConexionF\">Fierro</label>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\">Material de abrazadera</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 285
            $context["aguaMaterialAbrazadera"] = "";
            // line 286
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 286)) {
                $context["aguaMaterialAbrazadera"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 286, $this->source); })()), "contrato", [], "any", false, false, false, 286), "CTO_AGU_MAT_ABA", [], "any", false, false, false, 286);
                // line 287
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 287), "aguaMaterialAbrazadera", [], "any", true, true, false, 287)) {
                // line 288
                echo "                                \t    ";
                $context["aguaMaterialAbrazadera"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 288, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 288), "aguaMaterialAbrazadera", [], "any", false, false, false, 288);
            }
            // line 289
            echo "                                \t<div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"aguaMaterialAbrazadera\" 
                                        \t\tid=\"inpAguaMaterialAbrazaderaPVC\" value=\"pvc\"
                                        \t\t";
            // line 292
            if (((isset($context["aguaMaterialAbrazadera"]) || array_key_exists("aguaMaterialAbrazadera", $context) ? $context["aguaMaterialAbrazadera"] : (function () { throw new RuntimeError('Variable "aguaMaterialAbrazadera" does not exist.', 292, $this->source); })()) == "pvc")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAguaMaterialAbrazaderaPVC\">PVC</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"aguaMaterialAbrazadera\" 
                                        \t\tid=\"inpAguaMaterialAbrazaderaF\" value=\"fierro\"
                                        \t\t";
            // line 298
            if (((isset($context["aguaMaterialAbrazadera"]) || array_key_exists("aguaMaterialAbrazadera", $context) ? $context["aguaMaterialAbrazadera"] : (function () { throw new RuntimeError('Variable "aguaMaterialAbrazadera" does not exist.', 298, $this->source); })()) == "fierro")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAguaMaterialAbrazaderaF\">Fierro</label>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAguaUbicacionCaja\">Ubicacion de la caja</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 306
            $context["aguaUbicacionCaja"] = "";
            // line 307
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 307)) {
                $context["aguaUbicacionCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 307, $this->source); })()), "contrato", [], "any", false, false, false, 307), "CTO_AGU_UBI_CAJ", [], "any", false, false, false, 307);
                // line 308
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 308), "aguaUbicacionCaja", [], "any", true, true, false, 308)) {
                // line 309
                echo "                                \t    ";
                $context["aguaUbicacionCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 309, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 309), "aguaUbicacionCaja", [], "any", false, false, false, 309);
            }
            // line 310
            echo "                                \t<select name=\"aguaUbicacionCaja\" class=\"f_minwidth300\" id=\"cmbAguaUbicacionCaja\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"vereda\"
                                \t\t\t\t";
            // line 313
            if (((isset($context["aguaUbicacionCaja"]) || array_key_exists("aguaUbicacionCaja", $context) ? $context["aguaUbicacionCaja"] : (function () { throw new RuntimeError('Variable "aguaUbicacionCaja" does not exist.', 313, $this->source); })()) == "vereda")) {
                echo "selected";
            }
            echo ">
                                                Vereda
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"jardin\"
                                \t\t\t\t";
            // line 317
            if (((isset($context["aguaUbicacionCaja"]) || array_key_exists("aguaUbicacionCaja", $context) ? $context["aguaUbicacionCaja"] : (function () { throw new RuntimeError('Variable "aguaUbicacionCaja" does not exist.', 317, $this->source); })()) == "jardin")) {
                echo "selected";
            }
            echo ">
                                                Jardin
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"interior casa\"
                                \t\t\t\t";
            // line 321
            if (((isset($context["aguaUbicacionCaja"]) || array_key_exists("aguaUbicacionCaja", $context) ? $context["aguaUbicacionCaja"] : (function () { throw new RuntimeError('Variable "aguaUbicacionCaja" does not exist.', 321, $this->source); })()) == "interior casa")) {
                echo "selected";
            }
            echo ">
                                                Interior casa
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"no tiene\"
                                \t\t\t\t";
            // line 325
            if (((isset($context["aguaUbicacionCaja"]) || array_key_exists("aguaUbicacionCaja", $context) ? $context["aguaUbicacionCaja"] : (function () { throw new RuntimeError('Variable "aguaUbicacionCaja" does not exist.', 325, $this->source); })()) == "no tiene")) {
                echo "selected";
            }
            echo ">
                                                No tiene
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAguaMaterialCaja\">Material de la caja</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 334
            $context["aguaMaterialCaja"] = "";
            // line 335
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 335)) {
                $context["aguaMaterialCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 335, $this->source); })()), "contrato", [], "any", false, false, false, 335), "CTO_AGU_MAT_CAJ", [], "any", false, false, false, 335);
                // line 336
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 336), "aguaMaterialCaja", [], "any", true, true, false, 336)) {
                // line 337
                echo "                                \t    ";
                $context["aguaMaterialCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 337, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 337), "aguaMaterialCaja", [], "any", false, false, false, 337);
            }
            // line 338
            echo "                                \t<select name=\"aguaMaterialCaja\" class=\"f_minwidth300\" id=\"cmbAguaMaterialCaja\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"concreto\"
                                \t\t\t\t";
            // line 341
            if (((isset($context["aguaMaterialCaja"]) || array_key_exists("aguaMaterialCaja", $context) ? $context["aguaMaterialCaja"] : (function () { throw new RuntimeError('Variable "aguaMaterialCaja" does not exist.', 341, $this->source); })()) == "concreto")) {
                echo "selected";
            }
            echo ">
                                                Concreto
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"ladrillo\"
                                \t\t\t\t";
            // line 345
            if (((isset($context["aguaMaterialCaja"]) || array_key_exists("aguaMaterialCaja", $context) ? $context["aguaMaterialCaja"] : (function () { throw new RuntimeError('Variable "aguaMaterialCaja" does not exist.', 345, $this->source); })()) == "ladrillo")) {
                echo "selected";
            }
            echo ">
                                                Ladrillo
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"termoplastico\"
                                \t\t\t\t";
            // line 349
            if (((isset($context["aguaMaterialCaja"]) || array_key_exists("aguaMaterialCaja", $context) ? $context["aguaMaterialCaja"] : (function () { throw new RuntimeError('Variable "aguaMaterialCaja" does not exist.', 349, $this->source); })()) == "termoplastico")) {
                echo "selected";
            }
            echo ">
                                                Termoplastico
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAguaEstadoCaja\">Estado de la caja</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 358
            $context["aguaEstadoCaja"] = "";
            // line 359
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 359)) {
                $context["aguaEstadoCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 359, $this->source); })()), "contrato", [], "any", false, false, false, 359), "CTO_AGU_EST_CAJ", [], "any", false, false, false, 359);
                // line 360
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 360), "aguaEstadoCaja", [], "any", true, true, false, 360)) {
                // line 361
                echo "                                \t    ";
                $context["aguaEstadoCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 361, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 361), "aguaEstadoCaja", [], "any", false, false, false, 361);
            }
            // line 362
            echo "                                \t<select name=\"aguaEstadoCaja\" class=\"f_minwidth300\" id=\"cmbAguaEstadoCaja\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"buena\"
                                \t\t\t\t";
            // line 365
            if (((isset($context["aguaEstadoCaja"]) || array_key_exists("aguaEstadoCaja", $context) ? $context["aguaEstadoCaja"] : (function () { throw new RuntimeError('Variable "aguaEstadoCaja" does not exist.', 365, $this->source); })()) == "buena")) {
                echo "selected";
            }
            echo ">
                                                Buena
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"sucia\"
                                \t\t\t\t";
            // line 369
            if (((isset($context["aguaEstadoCaja"]) || array_key_exists("aguaEstadoCaja", $context) ? $context["aguaEstadoCaja"] : (function () { throw new RuntimeError('Variable "aguaEstadoCaja" does not exist.', 369, $this->source); })()) == "sucia")) {
                echo "selected";
            }
            echo ">
                                                Sucia
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"mal estado\"
                                \t\t\t\t";
            // line 373
            if (((isset($context["aguaEstadoCaja"]) || array_key_exists("aguaEstadoCaja", $context) ? $context["aguaEstadoCaja"] : (function () { throw new RuntimeError('Variable "aguaEstadoCaja" does not exist.', 373, $this->source); })()) == "mal estado")) {
                echo "selected";
            }
            echo ">
                                                Mal estado
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAguaMaterialTapa\">Material de la tapa</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 382
            $context["aguaMaterialTapa"] = "";
            // line 383
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 383)) {
                $context["aguaMaterialTapa"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 383, $this->source); })()), "contrato", [], "any", false, false, false, 383), "CTO_AGU_MAT_TAP", [], "any", false, false, false, 383);
                // line 384
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 384), "aguaMaterialTapa", [], "any", true, true, false, 384)) {
                // line 385
                echo "                                \t    ";
                $context["aguaMaterialTapa"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 385, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 385), "aguaMaterialTapa", [], "any", false, false, false, 385);
            }
            // line 386
            echo "                                \t<select name=\"aguaMaterialTapa\" class=\"f_minwidth300\" id=\"cmbAguaMaterialTapa\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"concreto\"
                                \t\t\t\t";
            // line 389
            if (((isset($context["aguaMaterialTapa"]) || array_key_exists("aguaMaterialTapa", $context) ? $context["aguaMaterialTapa"] : (function () { throw new RuntimeError('Variable "aguaMaterialTapa" does not exist.', 389, $this->source); })()) == "concreto")) {
                echo "selected";
            }
            echo ">
                                                Concreto
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"ladrillo\"
                                \t\t\t\t";
            // line 393
            if (((isset($context["aguaMaterialTapa"]) || array_key_exists("aguaMaterialTapa", $context) ? $context["aguaMaterialTapa"] : (function () { throw new RuntimeError('Variable "aguaMaterialTapa" does not exist.', 393, $this->source); })()) == "ladrillo")) {
                echo "selected";
            }
            echo ">
                                                Ladrillo
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"fierro\"
                                \t\t\t\t";
            // line 397
            if (((isset($context["aguaMaterialTapa"]) || array_key_exists("aguaMaterialTapa", $context) ? $context["aguaMaterialTapa"] : (function () { throw new RuntimeError('Variable "aguaMaterialTapa" does not exist.', 397, $this->source); })()) == "fierro")) {
                echo "selected";
            }
            echo ">
                                                Fierro
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"termoplastico\"
                                \t\t\t\t";
            // line 401
            if (((isset($context["aguaMaterialTapa"]) || array_key_exists("aguaMaterialTapa", $context) ? $context["aguaMaterialTapa"] : (function () { throw new RuntimeError('Variable "aguaMaterialTapa" does not exist.', 401, $this->source); })()) == "termoplastico")) {
                echo "selected";
            }
            echo ">
                                                Termoplastico
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"no tiene\"
                                \t\t\t\t";
            // line 405
            if (((isset($context["aguaMaterialTapa"]) || array_key_exists("aguaMaterialTapa", $context) ? $context["aguaMaterialTapa"] : (function () { throw new RuntimeError('Variable "aguaMaterialTapa" does not exist.', 405, $this->source); })()) == "no tiene")) {
                echo "selected";
            }
            echo ">
                                                No Tiene
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAguaEstadoTapa\">Estado de la tapa</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 414
            $context["aguaEstadoTapa"] = "";
            // line 415
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 415)) {
                $context["aguaEstadoTapa"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 415, $this->source); })()), "contrato", [], "any", false, false, false, 415), "CTO_AGU_EST_TAP", [], "any", false, false, false, 415);
                // line 416
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 416), "aguaEstadoTapa", [], "any", true, true, false, 416)) {
                // line 417
                echo "                                \t    ";
                $context["aguaEstadoTapa"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 417, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 417), "aguaEstadoTapa", [], "any", false, false, false, 417);
            }
            // line 418
            echo "                                \t<select name=\"aguaEstadoTapa\" class=\"f_minwidth300\" id=\"cmbAguaEstadoTapa\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"buena\"
                                \t\t\t\t";
            // line 421
            if (((isset($context["aguaEstadoTapa"]) || array_key_exists("aguaEstadoTapa", $context) ? $context["aguaEstadoTapa"] : (function () { throw new RuntimeError('Variable "aguaEstadoTapa" does not exist.', 421, $this->source); })()) == "buena")) {
                echo "selected";
            }
            echo ">
                                                Buena
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"sellada\"
                                \t\t\t\t";
            // line 425
            if (((isset($context["aguaEstadoTapa"]) || array_key_exists("aguaEstadoTapa", $context) ? $context["aguaEstadoTapa"] : (function () { throw new RuntimeError('Variable "aguaEstadoTapa" does not exist.', 425, $this->source); })()) == "sellada")) {
                echo "selected";
            }
            echo ">
                                                Sellada
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"mal estado\"
                                \t\t\t\t";
            // line 429
            if (((isset($context["aguaEstadoTapa"]) || array_key_exists("aguaEstadoTapa", $context) ? $context["aguaEstadoTapa"] : (function () { throw new RuntimeError('Variable "aguaEstadoTapa" does not exist.', 429, $this->source); })()) == "mal estado")) {
                echo "selected";
            }
            echo ">
                                                Mal estado
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                        </div>";
            // line 436
            echo "                        ";
        }
        // line 437
        echo "                        
                        
                        ";
        // line 439
        if ((isset($context["tieneDesague"]) || array_key_exists("tieneDesague", $context) ? $context["tieneDesague"] : (function () { throw new RuntimeError('Variable "tieneDesague" does not exist.', 439, $this->source); })())) {
            // line 440
            echo "                        ";
            // line 441
            echo "                        <div id=\"divNuevoContratoMasDetallesAlc\">
                            <h5 class=\"my-4 text-bold\">Servicio de Alcantarillado</h5>
                    \t\t<div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"inpAlcFechaConexion\">Fecha de conexion</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 446
            $context["alcFechaConexion"] = "";
            // line 447
            echo "                                \t";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 447)) {
                $context["alcFechaConexion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 447, $this->source); })()), "contrato", [], "any", false, false, false, 447), "CTO_ALC_FEC_INS", [], "any", false, false, false, 447);
                // line 448
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 448), "alcFechaConexion", [], "any", true, true, false, 448)) {
                // line 449
                echo "                                \t    ";
                $context["alcFechaConexion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 449, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 449), "alcFechaConexion", [], "any", false, false, false, 449);
            }
            // line 450
            echo "                                \t<input type=\"date\" class=\"f_minwidth300\" id=\"inpAlcFechaConexion\" name=\"alcFechaConexion\" 
                                \t\t\tvalue=\"";
            // line 451
            echo twig_escape_filter($this->env, (isset($context["alcFechaConexion"]) || array_key_exists("alcFechaConexion", $context) ? $context["alcFechaConexion"] : (function () { throw new RuntimeError('Variable "alcFechaConexion" does not exist.', 451, $this->source); })()), "html", null, true);
            echo "\">
                                </div>
                            </div>
                    \t\t<div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\">Característica de la conexion</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 457
            $context["alcConexionCaracteristica"] = "";
            // line 458
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 458)) {
                $context["alcConexionCaracteristica"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 458, $this->source); })()), "contrato", [], "any", false, false, false, 458), "CTO_ALC_CAR_CNX", [], "any", false, false, false, 458);
                // line 459
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 459), "alcConexionCaracteristica", [], "any", true, true, false, 459)) {
                // line 460
                echo "                                \t    ";
                $context["alcConexionCaracteristica"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 460, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 460), "alcConexionCaracteristica", [], "any", false, false, false, 460);
            }
            // line 461
            echo "                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcConexionCaracteristica\" 
                                        \t\tid=\"inpAlcConexionCaracteristicaSC\" value=\"sin caja\"
                                        \t\t";
            // line 464
            if (((isset($context["alcConexionCaracteristica"]) || array_key_exists("alcConexionCaracteristica", $context) ? $context["alcConexionCaracteristica"] : (function () { throw new RuntimeError('Variable "alcConexionCaracteristica" does not exist.', 464, $this->source); })()) == "sin caja")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcConexionCaracteristicaSC\">Sin caja</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcConexionCaracteristica\" 
                                        \t\tid=\"inpAlcConexionCaracteristicaCC\" value=\"con caja\"
                                        \t\t";
            // line 470
            if (((isset($context["alcConexionCaracteristica"]) || array_key_exists("alcConexionCaracteristica", $context) ? $context["alcConexionCaracteristica"] : (function () { throw new RuntimeError('Variable "alcConexionCaracteristica" does not exist.', 470, $this->source); })()) == "con caja")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcConexionCaracteristicaCC\">Con caja</label>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\">Tipo de conexion</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 478
            $context["alcTipoConexion"] = "";
            // line 479
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 479)) {
                $context["alcTipoConexion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 479, $this->source); })()), "contrato", [], "any", false, false, false, 479), "CTO_ALC_TIP_CNX", [], "any", false, false, false, 479);
                // line 480
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 480), "alcTipoConexion", [], "any", true, true, false, 480)) {
                // line 481
                echo "                                \t    ";
                $context["alcTipoConexion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 481, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 481), "alcTipoConexion", [], "any", false, false, false, 481);
            }
            // line 482
            echo "                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcTipoConexion\" 
                                        \t\tid=\"inpAlcTipoConexionCV\" value=\"convencional\"
                                        \t\t";
            // line 485
            if (((isset($context["alcTipoConexion"]) || array_key_exists("alcTipoConexion", $context) ? $context["alcTipoConexion"] : (function () { throw new RuntimeError('Variable "alcTipoConexion" does not exist.', 485, $this->source); })()) == "convencional")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcTipoConexionCV\">Convencional</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcTipoConexion\" 
                                        \t\tid=\"inpAlcTipoConexionCD\" value=\"condominial\"
                                        \t\t";
            // line 491
            if (((isset($context["alcTipoConexion"]) || array_key_exists("alcTipoConexion", $context) ? $context["alcTipoConexion"] : (function () { throw new RuntimeError('Variable "alcTipoConexion" does not exist.', 491, $this->source); })()) == "condominial")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcTipoConexionCD\">Condominial</label>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\">Diametro de la conexion</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 499
            $context["alcConexionDiametro"] = "";
            // line 500
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 500)) {
                $context["alcConexionDiametro"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 500, $this->source); })()), "contrato", [], "any", false, false, false, 500), "CTO_ALC_DTO_CNX", [], "any", false, false, false, 500);
                // line 501
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 501), "alcConexionDiametro", [], "any", true, true, false, 501)) {
                // line 502
                echo "                                \t    ";
                $context["alcConexionDiametro"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 502, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 502), "alcConexionDiametro", [], "any", false, false, false, 502);
            }
            // line 503
            echo "                                \t<div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcConexionDiametro\" 
                                        \t\tid=\"inpAlcConexionDiametro4\" value=\"4\"
                                        \t\t";
            // line 506
            if (((isset($context["alcConexionDiametro"]) || array_key_exists("alcConexionDiametro", $context) ? $context["alcConexionDiametro"] : (function () { throw new RuntimeError('Variable "alcConexionDiametro" does not exist.', 506, $this->source); })()) == "4")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcConexionDiametro4\">4\"</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcConexionDiametro\" 
                                        \t\tid=\"inpAlcConexionDiametro6\" value=\"6\"
                                        \t\t";
            // line 512
            if (((isset($context["alcConexionDiametro"]) || array_key_exists("alcConexionDiametro", $context) ? $context["alcConexionDiametro"] : (function () { throw new RuntimeError('Variable "alcConexionDiametro" does not exist.', 512, $this->source); })()) == "6")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcConexionDiametro6\">6\"</label>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\">Diametro de la red</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 520
            $context["alcDiametroRed"] = "";
            // line 521
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 521)) {
                $context["alcDiametroRed"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 521, $this->source); })()), "contrato", [], "any", false, false, false, 521), "CTO_ALC_DTO_RED", [], "any", false, false, false, 521);
                // line 522
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 522), "alcDiametroRed", [], "any", true, true, false, 522)) {
                // line 523
                echo "                                \t    ";
                $context["alcDiametroRed"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 523, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 523), "alcDiametroRed", [], "any", false, false, false, 523);
            }
            // line 524
            echo "                                \t<div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcDiametroRed\" 
                                        \t\tid=\"inpAlcDiametroRed4\" value=\"4\"
                                        \t\t";
            // line 527
            if (((isset($context["alcDiametroRed"]) || array_key_exists("alcDiametroRed", $context) ? $context["alcDiametroRed"] : (function () { throw new RuntimeError('Variable "alcDiametroRed" does not exist.', 527, $this->source); })()) == "4")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcDiametroRed4\">4\"</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcDiametroRed\" 
                                        \t\tid=\"inpAlcDiametroRed6\" value=\"6\"
                                        \t\t";
            // line 533
            if (((isset($context["alcDiametroRed"]) || array_key_exists("alcDiametroRed", $context) ? $context["alcDiametroRed"] : (function () { throw new RuntimeError('Variable "alcDiametroRed" does not exist.', 533, $this->source); })()) == "6")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcDiametroRed6\">6\"</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcDiametroRed\" 
                                        \t\tid=\"inpAlcDiametroRed8\" value=\"8\"
                                        \t\t";
            // line 539
            if (((isset($context["alcDiametroRed"]) || array_key_exists("alcDiametroRed", $context) ? $context["alcDiametroRed"] : (function () { throw new RuntimeError('Variable "alcDiametroRed" does not exist.', 539, $this->source); })()) == "8")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcDiametroRed8\">8\"</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcDiametroRed\" 
                                        \t\tid=\"inpAlcDiametroRed10\" value=\"10\"
                                        \t\t";
            // line 545
            if (((isset($context["alcDiametroRed"]) || array_key_exists("alcDiametroRed", $context) ? $context["alcDiametroRed"] : (function () { throw new RuntimeError('Variable "alcDiametroRed" does not exist.', 545, $this->source); })()) == "10")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcDiametroRed10\">10\"</label>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\">Material de conexion</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 553
            $context["alcMaterialConexion"] = "";
            // line 554
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 554)) {
                $context["alcMaterialConexion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 554, $this->source); })()), "contrato", [], "any", false, false, false, 554), "CTO_ALC_MAT_CNX", [], "any", false, false, false, 554);
                // line 555
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 555), "alcMaterialConexion", [], "any", true, true, false, 555)) {
                // line 556
                echo "                                \t    ";
                $context["alcMaterialConexion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 556, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 556), "alcMaterialConexion", [], "any", false, false, false, 556);
            }
            // line 557
            echo "                                \t<div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcMaterialConexion\" 
                                        \t\tid=\"inpAlcMaterialConexionPVC\" value=\"pvc\"
                                        \t\t";
            // line 560
            if (((isset($context["alcMaterialConexion"]) || array_key_exists("alcMaterialConexion", $context) ? $context["alcMaterialConexion"] : (function () { throw new RuntimeError('Variable "alcMaterialConexion" does not exist.', 560, $this->source); })()) == "pvc")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcMaterialConexionPVC\">PVC</label>
                                    </div>
                                    <div class=\"form-check form-check-inline\">
                                        <input class=\"form-check-input\" type=\"radio\" name=\"alcMaterialConexion\" 
                                        \t\tid=\"inpAlcMaterialConexionF\" value=\"fierro\"
                                        \t\t";
            // line 566
            if (((isset($context["alcMaterialConexion"]) || array_key_exists("alcMaterialConexion", $context) ? $context["alcMaterialConexion"] : (function () { throw new RuntimeError('Variable "alcMaterialConexion" does not exist.', 566, $this->source); })()) == "fierro")) {
                echo "checked";
            }
            echo ">
                                        <label class=\"form-check-label\" for=\"inpAlcMaterialConexionF\">Fierro</label>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAlcUbicacionCaja\">Ubicacion de la caja</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 574
            $context["alcUbicacionCaja"] = "";
            // line 575
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 575)) {
                $context["alcUbicacionCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 575, $this->source); })()), "contrato", [], "any", false, false, false, 575), "CTO_ALC_UBI_CAJ", [], "any", false, false, false, 575);
                // line 576
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 576), "alcUbicacionCaja", [], "any", true, true, false, 576)) {
                // line 577
                echo "                                \t    ";
                $context["alcUbicacionCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 577, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 577), "alcUbicacionCaja", [], "any", false, false, false, 577);
            }
            // line 578
            echo "                                \t<select name=\"alcUbicacionCaja\" class=\"f_minwidth300\" id=\"cmbAlcUbicacionCaja\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"vereda\"
                                \t\t\t\t";
            // line 581
            if (((isset($context["alcUbicacionCaja"]) || array_key_exists("alcUbicacionCaja", $context) ? $context["alcUbicacionCaja"] : (function () { throw new RuntimeError('Variable "alcUbicacionCaja" does not exist.', 581, $this->source); })()) == "vereda")) {
                echo "selected";
            }
            echo ">
                                                Vereda
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"jardin\"
                                \t\t\t\t";
            // line 585
            if (((isset($context["alcUbicacionCaja"]) || array_key_exists("alcUbicacionCaja", $context) ? $context["alcUbicacionCaja"] : (function () { throw new RuntimeError('Variable "alcUbicacionCaja" does not exist.', 585, $this->source); })()) == "jardin")) {
                echo "selected";
            }
            echo ">
                                                Jardin
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"interior casa\"
                                \t\t\t\t";
            // line 589
            if (((isset($context["alcUbicacionCaja"]) || array_key_exists("alcUbicacionCaja", $context) ? $context["alcUbicacionCaja"] : (function () { throw new RuntimeError('Variable "alcUbicacionCaja" does not exist.', 589, $this->source); })()) == "interior casa")) {
                echo "selected";
            }
            echo ">
                                                Interior casa
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"no tiene\"
                                \t\t\t\t";
            // line 593
            if (((isset($context["alcUbicacionCaja"]) || array_key_exists("alcUbicacionCaja", $context) ? $context["alcUbicacionCaja"] : (function () { throw new RuntimeError('Variable "alcUbicacionCaja" does not exist.', 593, $this->source); })()) == "no tiene")) {
                echo "selected";
            }
            echo ">
                                                No tiene
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAlcMaterialCaja\">Material de la caja</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 602
            $context["alcMaterialCaja"] = "";
            // line 603
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 603)) {
                $context["alcMaterialCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 603, $this->source); })()), "contrato", [], "any", false, false, false, 603), "CTO_ALC_MAT_CAJ", [], "any", false, false, false, 603);
                // line 604
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 604), "alcMaterialCaja", [], "any", true, true, false, 604)) {
                // line 605
                echo "                                \t    ";
                $context["alcMaterialCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 605, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 605), "alcMaterialCaja", [], "any", false, false, false, 605);
            }
            // line 606
            echo "                                \t<select name=\"alcMaterialCaja\" class=\"f_minwidth300\" id=\"cmbAlcMaterialCaja\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"concreto\"
                                \t\t\t\t";
            // line 609
            if (((isset($context["alcMaterialCaja"]) || array_key_exists("alcMaterialCaja", $context) ? $context["alcMaterialCaja"] : (function () { throw new RuntimeError('Variable "alcMaterialCaja" does not exist.', 609, $this->source); })()) == "concreto")) {
                echo "selected";
            }
            echo ">
                                                Concreto
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"ladrillo\"
                                \t\t\t\t";
            // line 613
            if (((isset($context["alcMaterialCaja"]) || array_key_exists("alcMaterialCaja", $context) ? $context["alcMaterialCaja"] : (function () { throw new RuntimeError('Variable "alcMaterialCaja" does not exist.', 613, $this->source); })()) == "ladrillo")) {
                echo "selected";
            }
            echo ">
                                                Ladrillo
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"termoplastico\"
                                \t\t\t\t";
            // line 617
            if (((isset($context["alcMaterialCaja"]) || array_key_exists("alcMaterialCaja", $context) ? $context["alcMaterialCaja"] : (function () { throw new RuntimeError('Variable "alcMaterialCaja" does not exist.', 617, $this->source); })()) == "termoplastico")) {
                echo "selected";
            }
            echo ">
                                                Termoplastico
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAlcEstadoCaja\">Estado de la caja</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 626
            $context["alcEstadoCaja"] = "";
            // line 627
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 627)) {
                $context["alcEstadoCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 627, $this->source); })()), "contrato", [], "any", false, false, false, 627), "CTO_ALC_EST_CAJ", [], "any", false, false, false, 627);
                // line 628
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 628), "alcEstadoCaja", [], "any", true, true, false, 628)) {
                // line 629
                echo "                                \t    ";
                $context["alcEstadoCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 629, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 629), "alcEstadoCaja", [], "any", false, false, false, 629);
            }
            // line 630
            echo "                                \t<select name=\"alcEstadoCaja\" class=\"f_minwidth300\" id=\"cmbAlcEstadoCaja\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"buena\"
                                \t\t\t\t";
            // line 633
            if (((isset($context["alcEstadoCaja"]) || array_key_exists("alcEstadoCaja", $context) ? $context["alcEstadoCaja"] : (function () { throw new RuntimeError('Variable "alcEstadoCaja" does not exist.', 633, $this->source); })()) == "buena")) {
                echo "selected";
            }
            echo ">
                                                Buena
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"sucia\"
                                \t\t\t\t";
            // line 637
            if (((isset($context["alcEstadoCaja"]) || array_key_exists("alcEstadoCaja", $context) ? $context["alcEstadoCaja"] : (function () { throw new RuntimeError('Variable "alcEstadoCaja" does not exist.', 637, $this->source); })()) == "sucia")) {
                echo "selected";
            }
            echo ">
                                                Sucia
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"mal estado\"
                                \t\t\t\t";
            // line 641
            if (((isset($context["alcEstadoCaja"]) || array_key_exists("alcEstadoCaja", $context) ? $context["alcEstadoCaja"] : (function () { throw new RuntimeError('Variable "alcEstadoCaja" does not exist.', 641, $this->source); })()) == "mal estado")) {
                echo "selected";
            }
            echo ">
                                                Mal estado
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAlcDimencionCaja\">Dimención de la caja</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 650
            $context["alcDimencionCaja"] = "";
            // line 651
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 651)) {
                $context["alcDimencionCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 651, $this->source); })()), "contrato", [], "any", false, false, false, 651), "CTO_ALC_DIM_CAJ", [], "any", false, false, false, 651);
                // line 652
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 652), "alcDimencionCaja", [], "any", true, true, false, 652)) {
                // line 653
                echo "                                \t    ";
                $context["alcDimencionCaja"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 653, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 653), "alcDimencionCaja", [], "any", false, false, false, 653);
            }
            // line 654
            echo "                                \t<select name=\"alcDimencionCaja\" class=\"f_minwidth300\" id=\"cmbAlcDimencionCaja\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"70x40 cm\"
                                \t\t\t\t";
            // line 657
            if (((isset($context["alcDimencionCaja"]) || array_key_exists("alcDimencionCaja", $context) ? $context["alcDimencionCaja"] : (function () { throw new RuntimeError('Variable "alcDimencionCaja" does not exist.', 657, $this->source); })()) == "70x40 cm")) {
                echo "selected";
            }
            echo ">
                                                70 x 40 cm
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"60x40 cm\"
                                \t\t\t\t";
            // line 661
            if (((isset($context["alcDimencionCaja"]) || array_key_exists("alcDimencionCaja", $context) ? $context["alcDimencionCaja"] : (function () { throw new RuntimeError('Variable "alcDimencionCaja" does not exist.', 661, $this->source); })()) == "60x40 cm")) {
                echo "selected";
            }
            echo ">
                                                60 x 40 cm
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"otro\"
                                \t\t\t\t";
            // line 665
            if (((isset($context["alcDimencionCaja"]) || array_key_exists("alcDimencionCaja", $context) ? $context["alcDimencionCaja"] : (function () { throw new RuntimeError('Variable "alcDimencionCaja" does not exist.', 665, $this->source); })()) == "otro")) {
                echo "selected";
            }
            echo ">
                                                Otro
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAlcMaterialTapa\">Material de la tapa</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 674
            $context["alcMaterialTapa"] = "";
            // line 675
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 675)) {
                $context["alcMaterialTapa"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 675, $this->source); })()), "contrato", [], "any", false, false, false, 675), "CTO_ALC_MAT_TAP", [], "any", false, false, false, 675);
                // line 676
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 676), "alcMaterialTapa", [], "any", true, true, false, 676)) {
                // line 677
                echo "                                \t    ";
                $context["alcMaterialTapa"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 677, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 677), "alcMaterialTapa", [], "any", false, false, false, 677);
            }
            // line 678
            echo "                                \t<select name=\"alcMaterialTapa\" class=\"f_minwidth300\" id=\"cmbAlcMaterialTapa\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"concreto\"
                                \t\t\t\t";
            // line 681
            if (((isset($context["alcMaterialTapa"]) || array_key_exists("alcMaterialTapa", $context) ? $context["alcMaterialTapa"] : (function () { throw new RuntimeError('Variable "alcMaterialTapa" does not exist.', 681, $this->source); })()) == "concreto")) {
                echo "selected";
            }
            echo ">
                                                Concreto
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"fierro\"
                                \t\t\t\t";
            // line 685
            if (((isset($context["alcMaterialTapa"]) || array_key_exists("alcMaterialTapa", $context) ? $context["alcMaterialTapa"] : (function () { throw new RuntimeError('Variable "alcMaterialTapa" does not exist.', 685, $this->source); })()) == "fierro")) {
                echo "selected";
            }
            echo ">
                                                Fierro
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"madera\"
                                \t\t\t\t";
            // line 689
            if (((isset($context["alcMaterialTapa"]) || array_key_exists("alcMaterialTapa", $context) ? $context["alcMaterialTapa"] : (function () { throw new RuntimeError('Variable "alcMaterialTapa" does not exist.', 689, $this->source); })()) == "madera")) {
                echo "selected";
            }
            echo ">
                                                Madera
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"no tiene\"
                                \t\t\t\t";
            // line 693
            if (((isset($context["alcMaterialTapa"]) || array_key_exists("alcMaterialTapa", $context) ? $context["alcMaterialTapa"] : (function () { throw new RuntimeError('Variable "alcMaterialTapa" does not exist.', 693, $this->source); })()) == "no tiene")) {
                echo "selected";
            }
            echo ">
                                                No Tiene
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAlcEstadoTapa\">Estado de la tapa</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 702
            $context["alcEstadoTapa"] = "";
            // line 703
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 703)) {
                $context["alcEstadoTapa"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 703, $this->source); })()), "contrato", [], "any", false, false, false, 703), "CTO_ALC_EST_TAP", [], "any", false, false, false, 703);
                // line 704
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 704), "alcEstadoTapa", [], "any", true, true, false, 704)) {
                // line 705
                echo "                                \t    ";
                $context["alcEstadoTapa"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 705, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 705), "alcEstadoTapa", [], "any", false, false, false, 705);
            }
            // line 706
            echo "                                \t<select name=\"alcEstadoTapa\" class=\"f_minwidth300\" id=\"cmbAlcEstadoTapa\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"buena\"
                                \t\t\t\t";
            // line 709
            if (((isset($context["alcEstadoTapa"]) || array_key_exists("alcEstadoTapa", $context) ? $context["alcEstadoTapa"] : (function () { throw new RuntimeError('Variable "alcEstadoTapa" does not exist.', 709, $this->source); })()) == "buena")) {
                echo "selected";
            }
            echo ">
                                                Buena
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"sellada\"
                                \t\t\t\t";
            // line 713
            if (((isset($context["alcEstadoTapa"]) || array_key_exists("alcEstadoTapa", $context) ? $context["alcEstadoTapa"] : (function () { throw new RuntimeError('Variable "alcEstadoTapa" does not exist.', 713, $this->source); })()) == "sellada")) {
                echo "selected";
            }
            echo ">
                                                Sellada
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"mal estado\"
                                \t\t\t\t";
            // line 717
            if (((isset($context["alcEstadoTapa"]) || array_key_exists("alcEstadoTapa", $context) ? $context["alcEstadoTapa"] : (function () { throw new RuntimeError('Variable "alcEstadoTapa" does not exist.', 717, $this->source); })()) == "mal estado")) {
                echo "selected";
            }
            echo ">
                                                Mal estado
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"no tiene\"
                                \t\t\t\t";
            // line 721
            if (((isset($context["alcEstadoTapa"]) || array_key_exists("alcEstadoTapa", $context) ? $context["alcEstadoTapa"] : (function () { throw new RuntimeError('Variable "alcEstadoTapa" does not exist.', 721, $this->source); })()) == "no tiene")) {
                echo "selected";
            }
            echo ">
                                                No tiene
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                            <div class=\"form-group row\">
                            \t<label class=\"col-12 col-md-3 f_field\" for=\"cmbAlcMedidasTapa\">Medidas de la tapa</label>
                                <div class=\"col-12 col-md-9\">
                                \t";
            // line 730
            $context["alcMedidasTapa"] = "";
            // line 731
            echo "                        \t        ";
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "contrato", [], "any", true, true, false, 731)) {
                $context["alcMedidasTapa"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 731, $this->source); })()), "contrato", [], "any", false, false, false, 731), "CTO_ALC_MED_TAP", [], "any", false, false, false, 731);
                // line 732
                echo "                                \t";
            } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoContrato", [], "any", false, true, false, 732), "alcMedidasTapa", [], "any", true, true, false, 732)) {
                // line 733
                echo "                                \t    ";
                $context["alcMedidasTapa"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 733, $this->source); })()), "formNuevoContrato", [], "any", false, false, false, 733), "alcMedidasTapa", [], "any", false, false, false, 733);
            }
            // line 734
            echo "                                \t<select name=\"alcMedidasTapa\" class=\"f_minwidth300\" id=\"cmbAlcMedidasTapa\"> 
                                \t\t<option value=\"-1\"></option>
                                    \t<option value=\"62x32 cm\"
                                \t\t\t\t";
            // line 737
            if (((isset($context["alcMedidasTapa"]) || array_key_exists("alcMedidasTapa", $context) ? $context["alcMedidasTapa"] : (function () { throw new RuntimeError('Variable "alcMedidasTapa" does not exist.', 737, $this->source); })()) == "62x32 cm")) {
                echo "selected";
            }
            echo ">
                                                62 x 32 cm
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"54x34 cm\"
                                \t\t\t\t";
            // line 741
            if (((isset($context["alcMedidasTapa"]) || array_key_exists("alcMedidasTapa", $context) ? $context["alcMedidasTapa"] : (function () { throw new RuntimeError('Variable "alcMedidasTapa" does not exist.', 741, $this->source); })()) == "54x34 cm")) {
                echo "selected";
            }
            echo ">
                                                54 x 34 cm
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"53x53 cm\"
                                \t\t\t\t";
            // line 745
            if (((isset($context["alcMedidasTapa"]) || array_key_exists("alcMedidasTapa", $context) ? $context["alcMedidasTapa"] : (function () { throw new RuntimeError('Variable "alcMedidasTapa" does not exist.', 745, $this->source); })()) == "53x53 cm")) {
                echo "selected";
            }
            echo ">
                                                53 x 53 cm
                        \t\t\t\t</option>
                        \t\t\t\t<option value=\"otro\"
                                \t\t\t\t";
            // line 749
            if (((isset($context["alcMedidasTapa"]) || array_key_exists("alcMedidasTapa", $context) ? $context["alcMedidasTapa"] : (function () { throw new RuntimeError('Variable "alcMedidasTapa" does not exist.', 749, $this->source); })()) == "otro")) {
                echo "selected";
            }
            echo ">
                                                Otro
                        \t\t\t\t</option>
                                    </select>
                                </div>
                            </div>
                        </div>";
            // line 756
            echo "                        ";
        }
        // line 757
        echo "                        
                \t</div>";
        // line 759
        echo "          \t\t</div>
          \t</div><!-- /.card-body -->
      \t</div>
  \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
          \t\t<div class=\"f_cardfooter f_cardfooteractions text-center\">
        \t\t\t<button type=\"submit\" class=\"f_button f_buttonaction\">Guardar cambios</button>
        \t\t\t<a href=\"";
        // line 767
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 767, $this->source); })()), "html", null, true);
        echo "/contrato/lista\" class=\"f_linkbtn f_linkbtnaction\">Cancelar</a>
    \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-footer -->
  \t
  \t</form>";
        // line 773
        echo "  
</div><!-- /.card -->
    
";
    }

    // line 778
    public function block_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 779
        echo "
    ";
        // line 780
        $this->displayParentBlock("scripts", $context, $blocks);
        echo "
  
\t<script type=\"text/javascript\">
\t\t\$('#formEditarContrato').keypress(function(e) {
            if (e.which == 13) {
                return false;
            }
        });
        
        f_select2(\"#cmbCalle\");
        
        
        if(\$(\"#chkContratoInicio\").prop('checked')){
    \t\t\$(\"#inpFechaInicio\").prop(\"disabled\", false);
    \t}else{
    \t\t\$(\"#inpFechaInicio\").val(\"\");
    \t\t\$(\"#inpFechaInicio\").prop(\"disabled\", true);
    \t}
        
        \$(\"#chkContratoInicio\").change(function(){
        \tif(\$(\"#chkContratoInicio\").prop('checked')){
        \t\t\$(\"#inpFechaInicio\").prop(\"disabled\", false);
        \t}else{
        \t\t\$(\"#inpFechaInicio\").val(\"\");
        \t\t\$(\"#inpFechaInicio\").prop(\"disabled\", true);
        \t}
        });
\t</script>
";
    }

    public function getTemplateName()
    {
        return "/administration/contrato/contratoEdit.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1671 => 780,  1668 => 779,  1664 => 778,  1657 => 773,  1649 => 767,  1639 => 759,  1636 => 757,  1633 => 756,  1622 => 749,  1613 => 745,  1604 => 741,  1595 => 737,  1590 => 734,  1586 => 733,  1583 => 732,  1579 => 731,  1577 => 730,  1563 => 721,  1554 => 717,  1545 => 713,  1536 => 709,  1531 => 706,  1527 => 705,  1524 => 704,  1520 => 703,  1518 => 702,  1504 => 693,  1495 => 689,  1486 => 685,  1477 => 681,  1472 => 678,  1468 => 677,  1465 => 676,  1461 => 675,  1459 => 674,  1445 => 665,  1436 => 661,  1427 => 657,  1422 => 654,  1418 => 653,  1415 => 652,  1411 => 651,  1409 => 650,  1395 => 641,  1386 => 637,  1377 => 633,  1372 => 630,  1368 => 629,  1365 => 628,  1361 => 627,  1359 => 626,  1345 => 617,  1336 => 613,  1327 => 609,  1322 => 606,  1318 => 605,  1315 => 604,  1311 => 603,  1309 => 602,  1295 => 593,  1286 => 589,  1277 => 585,  1268 => 581,  1263 => 578,  1259 => 577,  1256 => 576,  1252 => 575,  1250 => 574,  1237 => 566,  1226 => 560,  1221 => 557,  1217 => 556,  1214 => 555,  1210 => 554,  1208 => 553,  1195 => 545,  1184 => 539,  1173 => 533,  1162 => 527,  1157 => 524,  1153 => 523,  1150 => 522,  1146 => 521,  1144 => 520,  1131 => 512,  1120 => 506,  1115 => 503,  1111 => 502,  1108 => 501,  1104 => 500,  1102 => 499,  1089 => 491,  1078 => 485,  1073 => 482,  1069 => 481,  1066 => 480,  1062 => 479,  1060 => 478,  1047 => 470,  1036 => 464,  1031 => 461,  1027 => 460,  1024 => 459,  1020 => 458,  1018 => 457,  1009 => 451,  1006 => 450,  1002 => 449,  999 => 448,  995 => 447,  993 => 446,  986 => 441,  984 => 440,  982 => 439,  978 => 437,  975 => 436,  964 => 429,  955 => 425,  946 => 421,  941 => 418,  937 => 417,  934 => 416,  930 => 415,  928 => 414,  914 => 405,  905 => 401,  896 => 397,  887 => 393,  878 => 389,  873 => 386,  869 => 385,  866 => 384,  862 => 383,  860 => 382,  846 => 373,  837 => 369,  828 => 365,  823 => 362,  819 => 361,  816 => 360,  812 => 359,  810 => 358,  796 => 349,  787 => 345,  778 => 341,  773 => 338,  769 => 337,  766 => 336,  762 => 335,  760 => 334,  746 => 325,  737 => 321,  728 => 317,  719 => 313,  714 => 310,  710 => 309,  707 => 308,  703 => 307,  701 => 306,  688 => 298,  677 => 292,  672 => 289,  668 => 288,  665 => 287,  661 => 286,  659 => 285,  646 => 277,  635 => 271,  630 => 268,  626 => 267,  623 => 266,  619 => 265,  617 => 264,  604 => 256,  593 => 250,  582 => 244,  577 => 241,  573 => 240,  570 => 239,  566 => 238,  564 => 237,  551 => 229,  540 => 223,  535 => 220,  531 => 219,  528 => 218,  524 => 217,  522 => 216,  509 => 208,  498 => 202,  493 => 199,  489 => 198,  486 => 197,  482 => 196,  480 => 195,  471 => 189,  468 => 188,  464 => 187,  461 => 186,  457 => 185,  455 => 184,  448 => 179,  446 => 178,  444 => 177,  440 => 175,  437 => 173,  434 => 172,  428 => 171,  423 => 170,  419 => 169,  414 => 168,  411 => 167,  409 => 166,  406 => 165,  403 => 164,  401 => 163,  390 => 155,  387 => 154,  382 => 153,  378 => 152,  376 => 151,  370 => 147,  362 => 143,  358 => 142,  355 => 141,  351 => 140,  349 => 139,  338 => 132,  334 => 131,  331 => 130,  329 => 129,  324 => 126,  322 => 125,  321 => 124,  318 => 123,  312 => 120,  307 => 119,  303 => 118,  301 => 117,  296 => 114,  290 => 110,  285 => 109,  281 => 108,  278 => 107,  274 => 106,  272 => 105,  263 => 99,  258 => 98,  254 => 97,  251 => 96,  247 => 95,  245 => 94,  236 => 88,  231 => 87,  227 => 86,  224 => 85,  220 => 84,  218 => 83,  209 => 77,  204 => 76,  199 => 75,  195 => 74,  193 => 73,  184 => 67,  179 => 66,  174 => 65,  170 => 64,  168 => 63,  158 => 57,  153 => 56,  151 => 55,  144 => 54,  142 => 53,  131 => 44,  125 => 39,  122 => 38,  113 => 36,  108 => 35,  106 => 34,  100 => 32,  97 => 31,  94 => 30,  91 => 29,  88 => 28,  85 => 27,  82 => 26,  79 => 25,  76 => 24,  58 => 9,  54 => 6,  50 => 5,  45 => 3,  43 => 1,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("", "/administration/contrato/contratoEdit.twig", "/home/jasschos/public_html/resources/views/administration/contrato/contratoEdit.twig");
    }
}
