<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /administration/usuario/userEdit.twig */
class __TwigTemplate_a869fad029647b3b334a970139dbb0f6f2e66336ef774d4a510831cf36ab611d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content_main' => [$this, 'block_content_main'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "administration/templateAdministration.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["menuLItem"] = "usuario";
        // line 3
        $this->parent = $this->loadTemplate("administration/templateAdministration.twig", "/administration/usuario/userEdit.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "
<div class=\"f_card\">
\t";
        // line 9
        echo "\t<form class=\"f_inputflat\" id=\"formEditarUsuario\" method=\"post\" action=\"";
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 9, $this->source); })()), "html", null, true);
        echo "/usuario/update\">
\t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t<div class=\"f_cardheader\">
      \t\t\t\t<div class=\"\"> 
                    \t<i class=\"fas fa-user-shield mr-3\"></i>Editar usuario
                \t</div>
      \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-header -->
      \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t";
        // line 24
        echo "                ";
        $context["classAlert"] = "";
        // line 25
        echo "                ";
        if (twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 25, $this->source); })()))) {
            // line 26
            echo "                \t";
            $context["classAlert"] = "d-none";
            // line 27
            echo "                ";
        } elseif ((((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) >= 200) && ((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) < 300))) {
            // line 28
            echo "                    ";
            $context["classAlert"] = "alert-success";
            // line 29
            echo "                ";
        } elseif (((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 29, $this->source); })()) >= 400)) {
            // line 30
            echo "                    ";
            $context["classAlert"] = "alert-danger";
            // line 31
            echo "                ";
        }
        // line 32
        echo "      \t\t\t<div class=\"alert ";
        echo twig_escape_filter($this->env, (isset($context["classAlert"]) || array_key_exists("classAlert", $context) ? $context["classAlert"] : (function () { throw new RuntimeError('Variable "classAlert" does not exist.', 32, $this->source); })()), "html", null, true);
        echo " alert-dismissible fade show\" id=\"f_alertsContainer\" role=\"alert\">
                 \t<ul class=\"mb-0\" id=\"f_alertsUl\">
                 \t\t";
        // line 34
        if ( !twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 34, $this->source); })()))) {
            // line 35
            echo "                          ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 35, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["msj"]) {
                // line 36
                echo "                            <li>";
                echo twig_escape_filter($this->env, $context["msj"], "html", null, true);
                echo "</li>
                          ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "                        ";
        }
        // line 39
        echo "                 \t</ul>
                 \t<button type=\"button\" class=\"close\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\" id=\"f_alertsDismiss\">
                 \t\t<span aria-hidden=\"true\">&times;</span>
                 \t</button>
                </div>";
        // line 44
        echo "      \t\t</div>
      \t</div>
      \t
      \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
          \t\t<div class=\"f_tabs\">
          \t\t\t<div class=\"f_tabactive\">
          \t\t\t\t<a href=\"#\" class=\"f_link\">Usuario</a>
          \t\t\t</div>
          \t\t\t<div class=\"f_tabunactive\">
          \t\t\t    ";
        // line 55
        $context["codigo"] = "";
        // line 56
        echo "                    \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 56)) {
            $context["codigo"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 56, $this->source); })()), "usuario", [], "any", false, false, false, 56), "USU_CODIGO", [], "any", false, false, false, 56);
            // line 57
            echo "                    \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarUsuario", [], "any", true, true, false, 57)) {
            $context["codigo"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 57, $this->source); })()), "formEditarUsuario", [], "any", false, false, false, 57), "codigo", [], "any", false, false, false, 57);
        }
        // line 58
        echo "          \t\t\t\t<a href=\"";
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 58, $this->source); })()), "html", null, true);
        echo "/usuario/editar/password/";
        echo twig_escape_filter($this->env, (isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 58, $this->source); })()), "html", null, true);
        echo "\" class=\"f_link\">Password</a>
          \t\t\t</div>
              \t</div>
      \t\t</div>
      \t</div><!-- /.tabs de contenido -->
  
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t
      \t\t\t<div class=\"f_divwithbartop f_divwithbarbottom\">
      \t\t\t\t<div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_field\">Ref.</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 71
        $context["codigo"] = "";
        // line 72
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 72)) {
            $context["codigo"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 72, $this->source); })()), "usuario", [], "any", false, false, false, 72), "USU_CODIGO", [], "any", false, false, false, 72);
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 72, $this->source); })()), "usuario", [], "any", false, false, false, 72), "USU_CODIGO", [], "any", false, false, false, 72), "html", null, true);
            echo "
                        \t";
        } elseif (twig_get_attribute($this->env, $this->source,         // line 73
($context["data"] ?? null), "formEditarUsuario", [], "any", true, true, false, 73)) {
            // line 74
            echo "                        \t    ";
            $context["codigo"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 74, $this->source); })()), "formEditarUsuario", [], "any", false, false, false, 74), "codigo", [], "any", false, false, false, 74);
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 74, $this->source); })()), "formEditarUsuario", [], "any", false, false, false, 74), "codigo", [], "any", false, false, false, 74), "html", null, true);
        }
        // line 75
        echo "                        \t<input type=\"hidden\" class=\"f_minwidth300\" id=\"inpCodigo\" name=\"codigo\" value='";
        echo twig_escape_filter($this->env, (isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 75, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpNombres\">Nombres</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 81
        $context["nombres"] = "";
        // line 82
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 82)) {
            $context["nombres"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 82, $this->source); })()), "usuario", [], "any", false, false, false, 82), "USU_NOMBRES", [], "any", false, false, false, 82);
            // line 83
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarUsuario", [], "any", true, true, false, 83)) {
            $context["nombres"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 83, $this->source); })()), "formEditarUsuario", [], "any", false, false, false, 83), "nombres", [], "any", false, false, false, 83);
        }
        // line 84
        echo "                        \t<input type=\"text\" class=\"f_minwidth300\" id=\"inpNombres\" name=\"nombres\" value='";
        echo twig_escape_filter($this->env, (isset($context["nombres"]) || array_key_exists("nombres", $context) ? $context["nombres"] : (function () { throw new RuntimeError('Variable "nombres" does not exist.', 84, $this->source); })()), "html", null, true);
        echo "' required>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpApellidos\">Apellidos</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 90
        $context["apellidos"] = "";
        // line 91
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 91)) {
            $context["apellidos"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 91, $this->source); })()), "usuario", [], "any", false, false, false, 91), "USU_APELLIDOS", [], "any", false, false, false, 91);
            // line 92
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarUsuario", [], "any", true, true, false, 92)) {
            $context["apellidos"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 92, $this->source); })()), "formEditarUsuario", [], "any", false, false, false, 92), "apellidos", [], "any", false, false, false, 92);
        }
        // line 93
        echo "                        \t<input type=\"text\" class=\"f_minwidth300\" id=\"inpApellidos\" name=\"apellidos\" value='";
        echo twig_escape_filter($this->env, (isset($context["apellidos"]) || array_key_exists("apellidos", $context) ? $context["apellidos"] : (function () { throw new RuntimeError('Variable "apellidos" does not exist.', 93, $this->source); })()), "html", null, true);
        echo "' required>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpUsuario\">Usuario</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 99
        $context["usuario"] = "";
        // line 100
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 100)) {
            $context["usuario"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 100, $this->source); })()), "usuario", [], "any", false, false, false, 100), "USU_USUARIO", [], "any", false, false, false, 100);
            // line 101
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarUsuario", [], "any", true, true, false, 101)) {
            $context["usuario"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 101, $this->source); })()), "formEditarUsuario", [], "any", false, false, false, 101), "usuario", [], "any", false, false, false, 101);
        }
        // line 102
        echo "                        \t<input type=\"text\" class=\"f_minwidth300\" id=\"inpUsuario\" name=\"usuario\" value='";
        echo twig_escape_filter($this->env, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 102, $this->source); })()), "html", null, true);
        echo "' required>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpEmail\">Email</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t<i class=\"fas fa-at mr-1\"></i>
                        \t";
        // line 109
        $context["email"] = "";
        // line 110
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 110)) {
            $context["email"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 110, $this->source); })()), "usuario", [], "any", false, false, false, 110), "USU_EMAIL", [], "any", false, false, false, 110);
            // line 111
            echo "                        \t";
        } elseif (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarUsuario", [], "any", true, true, false, 111)) {
            $context["email"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 111, $this->source); })()), "formEditarUsuario", [], "any", false, false, false, 111), "email", [], "any", false, false, false, 111);
        }
        // line 112
        echo "                        \t<input type=\"email\" class=\"f_minwidth300\" id=\"inpEmail\" name=\"email\" value='";
        echo twig_escape_filter($this->env, (isset($context["email"]) || array_key_exists("email", $context) ? $context["email"] : (function () { throw new RuntimeError('Variable "email" does not exist.', 112, $this->source); })()), "html", null, true);
        echo "' required>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"cmbTipo\">Tipo</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                            <select name=\"tipo\" class=\"f_minwidth200\" id=\"cmbTipo\" required>
                            \t";
        // line 119
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuarioTipos", [], "any", true, true, false, 119)) {
            // line 120
            echo "                            \t\t";
            $context["selectedTipo"] = false;
            // line 121
            echo "                            \t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 121, $this->source); })()), "usuarioTipos", [], "any", false, false, false, 121));
            foreach ($context['_seq'] as $context["_key"] => $context["tipoUsuario"]) {
                // line 122
                echo "                                    \t<option value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["tipoUsuario"], "TPU_CODIGO", [], "any", false, false, false, 122), "html", null, true);
                echo "\"
                                        \t\t";
                // line 123
                if ( !(isset($context["selectedTipo"]) || array_key_exists("selectedTipo", $context) ? $context["selectedTipo"] : (function () { throw new RuntimeError('Variable "selectedTipo" does not exist.', 123, $this->source); })())) {
                    // line 124
                    echo "                                    \t\t\t\t";
                    if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 124) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 124, $this->source); })()), "usuario", [], "any", false, false, false, 124), "TPU_CODIGO", [], "any", false, false, false, 124) == twig_get_attribute($this->env, $this->source, $context["tipoUsuario"], "TPU_CODIGO", [], "any", false, false, false, 124)))) {
                        // line 125
                        echo "                                    \t\t\t\t\t";
                        echo "selected";
                        $context["selectedTipo"] = true;
                        // line 126
                        echo "                                \t\t\t\t\t";
                    } elseif ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarUsuario", [], "any", true, true, false, 126) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source,                     // line 127
(isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 127, $this->source); })()), "formEditarUsuario", [], "any", false, false, false, 127), "tipo", [], "any", false, false, false, 127) == twig_get_attribute($this->env, $this->source, $context["tipoUsuario"], "TPU_CODIGO", [], "any", false, false, false, 127)))) {
                        // line 128
                        echo "                        \t\t\t\t\t            ";
                        echo "selected";
                        $context["selectedTipo"] = true;
                    }
                    // line 129
                    echo "                    \t\t\t\t\t         ";
                }
                echo ">
                            \t\t\t\t ";
                // line 130
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["tipoUsuario"], "TPU_NOMBRE", [], "any", false, false, false, 130), "html", null, true);
                echo "
                        \t\t\t\t</option>
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tipoUsuario'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 133
            echo "                            \t";
        }
        // line 134
        echo "                            </select>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"cmbEstado\">Estado</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                            <select name=\"estado\" class=\"f_minwidth200\" id=\"cmbEstado\" required>
                            \t";
        // line 141
        if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 141) || twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formEditarUsuario", [], "any", true, true, false, 141))) {
            // line 142
            echo "                                \t<option value=\"0\"
                                \t\t\t\t";
            // line 143
            if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 143) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 143, $this->source); })()), "usuario", [], "any", false, false, false, 143), "USU_ESTADO", [], "any", false, false, false, 143) == "0"))) {
                // line 144
                echo "                                \t\t\t\t\t";
                echo "selected";
                echo "
                            \t\t\t\t\t";
            } elseif ((twig_get_attribute($this->env, $this->source,             // line 145
($context["data"] ?? null), "formEditarUsuario", [], "any", true, true, false, 145) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 145, $this->source); })()), "formEditarUsuario", [], "any", false, false, false, 145), "estado", [], "any", false, false, false, 145) == "0"))) {
                // line 146
                echo "                            \t\t\t\t\t    ";
                echo "selected";
            }
            echo ">
                                \t\tSuspendido
                            \t\t</option>
                                \t<option value=\"1\"
                                \t\t\t\t";
            // line 150
            if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuario", [], "any", true, true, false, 150) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 150, $this->source); })()), "usuario", [], "any", false, false, false, 150), "USU_ESTADO", [], "any", false, false, false, 150) == "1"))) {
                // line 151
                echo "                                \t\t\t\t\t";
                echo "selected";
                echo "
                            \t\t\t\t\t";
            } elseif ((twig_get_attribute($this->env, $this->source,             // line 152
($context["data"] ?? null), "formEditarUsuario", [], "any", true, true, false, 152) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 152, $this->source); })()), "formEditarUsuario", [], "any", false, false, false, 152), "estado", [], "any", false, false, false, 152) == "1"))) {
                // line 153
                echo "                            \t\t\t\t\t    ";
                echo "selected";
            }
            echo ">
                                \t\tActivo
                            \t\t</option>
                        \t\t";
        }
        // line 157
        echo "                            </select>
                        </div>
                    </div>
                    
      \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-body -->
  \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
          \t\t<div class=\"f_cardfooter f_cardfooteractions text-center\">
        \t\t\t<button type=\"submit\" class=\"f_button f_buttonaction\">Guardar cambios</button>
        \t\t\t<a href=\"";
        // line 169
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 169, $this->source); })()), "html", null, true);
        echo "/usuario/lista\" class=\"f_linkbtn f_linkbtnaction\">Cancelar</a>
    \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-footer -->
  \t
  \t</form>";
        // line 175
        echo "  
</div><!-- /.card -->
    
";
    }

    // line 180
    public function block_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 181
        echo "
    ";
        // line 182
        $this->displayParentBlock("scripts", $context, $blocks);
        echo "
  
\t<script type=\"text/javascript\">
\t\t\$('#formEditarUsuario').keypress(function(e) {
            if (e.which == 13) {
                return false;
            }
        });
        
        f_select2(\"#cmbTipo\");
        f_select2(\"#cmbEstado\");
\t</script>
";
    }

    public function getTemplateName()
    {
        return "/administration/usuario/userEdit.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  422 => 182,  419 => 181,  415 => 180,  408 => 175,  400 => 169,  386 => 157,  377 => 153,  375 => 152,  370 => 151,  368 => 150,  359 => 146,  357 => 145,  352 => 144,  350 => 143,  347 => 142,  345 => 141,  336 => 134,  333 => 133,  324 => 130,  319 => 129,  314 => 128,  312 => 127,  310 => 126,  306 => 125,  303 => 124,  301 => 123,  296 => 122,  291 => 121,  288 => 120,  286 => 119,  275 => 112,  270 => 111,  266 => 110,  264 => 109,  253 => 102,  248 => 101,  244 => 100,  242 => 99,  232 => 93,  227 => 92,  223 => 91,  221 => 90,  211 => 84,  206 => 83,  202 => 82,  200 => 81,  190 => 75,  185 => 74,  183 => 73,  176 => 72,  174 => 71,  155 => 58,  150 => 57,  146 => 56,  144 => 55,  131 => 44,  125 => 39,  122 => 38,  113 => 36,  108 => 35,  106 => 34,  100 => 32,  97 => 31,  94 => 30,  91 => 29,  88 => 28,  85 => 27,  82 => 26,  79 => 25,  76 => 24,  58 => 9,  54 => 6,  50 => 5,  45 => 3,  43 => 1,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("", "/administration/usuario/userEdit.twig", "/home/jasschos/public_html/resources/views/administration/usuario/userEdit.twig");
    }
}
