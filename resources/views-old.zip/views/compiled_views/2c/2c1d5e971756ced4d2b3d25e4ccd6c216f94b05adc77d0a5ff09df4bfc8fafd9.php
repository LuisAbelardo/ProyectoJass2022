<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /administration/cliente/clienteDetail.twig */
class __TwigTemplate_f9fcdff9525c3e43ffd3781313b10320a38252cff9adb8c502b2426cf2372789 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content_main' => [$this, 'block_content_main'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "administration/templateAdministration.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["menuLItem"] = "cliente";
        // line 3
        $this->parent = $this->loadTemplate("administration/templateAdministration.twig", "/administration/cliente/clienteDetail.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "\t
<div class=\"f_card\">

  \t<div class=\"row\">
  \t\t<div class=\"col-12\">
  \t\t\t<div class=\"f_cardheader\">
  \t\t\t\t<div class=\"\"> 
                \t<i class=\"fas fa-user mr-3\"></i>Detalle de cliente 
            \t</div>
  \t\t\t</div>
  \t\t</div>
  \t</div><!-- /.card-header -->
  \t
  \t<div class=\"row\">
  \t\t<div class=\"col-12\">
  \t\t\t";
        // line 22
        echo "            ";
        $context["classAlert"] = "";
        // line 23
        echo "            ";
        if (twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 23, $this->source); })()))) {
            // line 24
            echo "            \t";
            $context["classAlert"] = "d-none";
            // line 25
            echo "            ";
        } elseif ((((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 25, $this->source); })()) >= 200) && ((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 25, $this->source); })()) < 300))) {
            // line 26
            echo "                ";
            $context["classAlert"] = "alert-success";
            // line 27
            echo "            ";
        } elseif (((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) >= 400)) {
            // line 28
            echo "                ";
            $context["classAlert"] = "alert-danger";
            // line 29
            echo "            ";
        }
        // line 30
        echo "  \t\t\t<div class=\"alert ";
        echo twig_escape_filter($this->env, (isset($context["classAlert"]) || array_key_exists("classAlert", $context) ? $context["classAlert"] : (function () { throw new RuntimeError('Variable "classAlert" does not exist.', 30, $this->source); })()), "html", null, true);
        echo " alert-dismissible fade show\" id=\"f_alertsContainer\" role=\"alert\">
             \t<ul class=\"mb-0\" id=\"f_alertsUl\">
             \t\t";
        // line 32
        if ( !twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 32, $this->source); })()))) {
            // line 33
            echo "                      ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 33, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["msj"]) {
                // line 34
                echo "                        <li>";
                echo twig_escape_filter($this->env, $context["msj"], "html", null, true);
                echo "</li>
                      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "                    ";
        }
        // line 37
        echo "             \t</ul>
             \t<button type=\"button\" class=\"close\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\" id=\"f_alertsDismiss\">
             \t\t<span aria-hidden=\"true\">&times;</span>
             \t</button>
            </div>";
        // line 42
        echo "  \t\t</div>
  \t</div>
  \t
  
  \t<div class=\"row\">
  \t\t<div class=\"col-12 d-flex justify-content-between f_arearef\">
  \t\t\t<div>
  \t\t\t\t<div class=\"d-inline-block mr-2 mr-md-4\">
          \t\t\t<div class=\"f_imageref\"><span class=\"fas fa-user\" style=\" color: #a69944\"></span></div>
  \t\t\t\t</div>
  \t\t\t\t<div class=\"d-inline-block align-top\">
  \t\t\t\t\t<span class=\"font-weight-bold f_inforef\">
  \t\t\t\t\t    ";
        // line 54
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 54)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 54, $this->source); })()), "cliente", [], "any", false, false, false, 54), "CLI_CODIGO", [], "any", false, false, false, 54), "html", null, true);
        }
        // line 55
        echo "  \t\t\t\t\t</span><br/>
  \t\t\t\t\t<span class=\"font-weight-bold f_inforef\">
  \t\t\t\t\t    ";
        // line 57
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 57)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 57, $this->source); })()), "cliente", [], "any", false, false, false, 57), "CLI_NOMBRES", [], "any", false, false, false, 57), "html", null, true);
        }
        // line 58
        echo "\t\t\t\t    </span><br/>
  \t\t\t\t</div>
  \t\t\t</div>
  \t\t\t<div class=\"d-none d-sm-block\">
  \t\t\t\t<span><a href=\"";
        // line 62
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 62, $this->source); })()), "html", null, true);
        echo "/cliente/lista\" class=\"f_link font-weight-bold\">Volver a Lista</a></span>
  \t\t\t</div>
  \t\t</div>
  \t\t<div class=\"col-12 table-responsive\">
  \t\t\t<table class=\"table f_table f_tableforfield\">
              <tbody>
              \t<tr>
                  <td>Ref.</td>
                  <td>";
        // line 70
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 70)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 70, $this->source); })()), "cliente", [], "any", false, false, false, 70), "CLI_CODIGO", [], "any", false, false, false, 70), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Tipo</td>
                  <td>
                  \t";
        // line 75
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 75)) {
            // line 76
            echo "                  \t\t";
            if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 76, $this->source); })()), "cliente", [], "any", false, false, false, 76), "CLI_TIPO", [], "any", false, false, false, 76) == 1)) {
                // line 77
                echo "                        \t";
                echo "Natural";
                echo "
                        ";
            } elseif ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source,             // line 78
(isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 78, $this->source); })()), "cliente", [], "any", false, false, false, 78), "CLI_TIPO", [], "any", false, false, false, 78) == 2)) {
                // line 79
                echo "                        \t";
                echo "Juridico";
                echo "
                        ";
            }
            // line 81
            echo "                  \t";
        }
        // line 82
        echo "                  </td>
                </tr>
                <tr>
                \t<td>
                \t\t";
        // line 86
        if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 86) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 86, $this->source); })()), "cliente", [], "any", false, false, false, 86), "CLI_TIPO", [], "any", false, false, false, 86) == 1))) {
            // line 87
            echo "                \t\t\t";
            echo "DNI";
            echo "
            \t\t\t";
        } else {
            // line 88
            echo "RUC";
        }
        // line 89
        echo "                \t</td>
                  \t<td>";
        // line 90
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 90)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 90, $this->source); })()), "cliente", [], "any", false, false, false, 90), "CLI_DOCUMENTO", [], "any", false, false, false, 90), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>
                  \t    ";
        // line 94
        if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 94) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 94, $this->source); })()), "cliente", [], "any", false, false, false, 94), "CLI_TIPO", [], "any", false, false, false, 94) == 1))) {
            // line 95
            echo "                \t\t\t";
            echo "Nombre";
            echo "
            \t\t\t";
        } else {
            // line 96
            echo "Razón social";
        }
        // line 97
        echo "                  </td>
                  <td>";
        // line 98
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 98)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 98, $this->source); })()), "cliente", [], "any", false, false, false, 98), "CLI_NOMBRES", [], "any", false, false, false, 98), "html", null, true);
        }
        echo "</td>
                </tr>
                
                ";
        // line 101
        if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 101) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 101, $this->source); })()), "cliente", [], "any", false, false, false, 101), "CLI_TIPO", [], "any", false, false, false, 101) == 1))) {
            // line 102
            echo "                \t<tr>
                      <td>Fecha Nacimiento</td>
                      <td>";
            // line 104
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 104, $this->source); })()), "cliente", [], "any", false, false, false, 104), "CLI_FECHA_NAC", [], "any", false, false, false, 104), "html", null, true);
            echo "</td>
                    </tr>
            \t";
        }
        // line 107
        echo "            \t
            \t";
        // line 108
        if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 108) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 108, $this->source); })()), "cliente", [], "any", false, false, false, 108), "CLI_TIPO", [], "any", false, false, false, 108) == 2))) {
            // line 109
            echo "                \t<tr>
                      <td>Representante legal</td>
                      <td>";
            // line 111
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 111, $this->source); })()), "cliente", [], "any", false, false, false, 111), "CLI_REPRES_LEGAL", [], "any", false, false, false, 111), "html", null, true);
            echo "</td>
                    </tr>
            \t";
        }
        // line 114
        echo "            \t\t\t
                <tr>
                  <td>Departamento</td>
                  <td>";
        // line 117
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 117)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 117, $this->source); })()), "cliente", [], "any", false, false, false, 117), "CLI_DEPARTAMENTO", [], "any", false, false, false, 117), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Provincia</td>
                  <td>";
        // line 121
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 121)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 121, $this->source); })()), "cliente", [], "any", false, false, false, 121), "CLI_PROVINCIA", [], "any", false, false, false, 121), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Distrito</td>
                  <td>";
        // line 125
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 125)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 125, $this->source); })()), "cliente", [], "any", false, false, false, 125), "CLI_DISTRITO", [], "any", false, false, false, 125), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Dirección</td>
                  <td>";
        // line 129
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 129)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 129, $this->source); })()), "cliente", [], "any", false, false, false, 129), "CLI_DIRECCION", [], "any", false, false, false, 129), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Telefono</td>
                  <td>";
        // line 133
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 133)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 133, $this->source); })()), "cliente", [], "any", false, false, false, 133), "CLI_TELEFONO", [], "any", false, false, false, 133), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Email</td>
                  <td>";
        // line 137
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 137)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 137, $this->source); })()), "cliente", [], "any", false, false, false, 137), "CLI_EMAIL", [], "any", false, false, false, 137), "html", null, true);
        }
        echo "</td>
                </tr>
                <tr>
                  <td>Fecha de creación</td>
                  <td>";
        // line 141
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 141)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 141, $this->source); })()), "cliente", [], "any", false, false, false, 141), "CLI_CREATED", [], "any", false, false, false, 141), "html", null, true);
        }
        echo "</td>
                </tr>
              </tbody>
            </table>
  \t\t</div>
  \t</div><!-- /.card-body -->
  \t
  \t<div class=\"row\">
  \t\t<div class=\"col-12\">
  \t\t\t<div class=\"f_cardfooter f_cardfooteractions text-right\">
  \t\t\t\t<a href=\"";
        // line 151
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 151, $this->source); })()), "html", null, true);
        echo "/cliente/editar/";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 151)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 151, $this->source); })()), "cliente", [], "any", false, false, false, 151), "CLI_CODIGO", [], "any", false, false, false, 151), "html", null, true);
        }
        echo "\" 
  \t\t\t\t\tclass=\"f_linkbtn f_linkbtnaction\">Modificar</a>
\t\t\t\t";
        // line 153
        list($context["styleBtnEliminar"], $context["titleBtnEliminar"]) =         ["f_buttonactiondelete", ""];
        // line 154
        echo "\t\t\t\t";
        if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "predios", [], "any", true, true, false, 154) &&  !twig_test_empty(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 154, $this->source); })()), "predios", [], "any", false, false, false, 154)))) {
            // line 155
            echo "\t\t\t\t    ";
            $context["styleBtnEliminar"] = "f_buttonactionrefused";
            // line 156
            echo "\t\t\t\t    ";
            $context["titleBtnEliminar"] = "Desactivado porque el cliente no se puede borrar.
\t\t\t\t    \t\t\t\t\t\t\tSe han creado predios asociados a este cliente";
            // line 158
            echo "\t\t\t    ";
        }
        // line 159
        echo "  \t\t\t\t<button type=\"button\" class=\"f_button ";
        echo twig_escape_filter($this->env, (isset($context["styleBtnEliminar"]) || array_key_exists("styleBtnEliminar", $context) ? $context["styleBtnEliminar"] : (function () { throw new RuntimeError('Variable "styleBtnEliminar" does not exist.', 159, $this->source); })()), "html", null, true);
        echo " classfortooltip\" data-toggle=\"modal\" data-target=\"#modalEliminarCliente\"
  \t\t\t\t\t\ttitle=\"";
        // line 160
        echo twig_escape_filter($this->env, (isset($context["titleBtnEliminar"]) || array_key_exists("titleBtnEliminar", $context) ? $context["titleBtnEliminar"] : (function () { throw new RuntimeError('Variable "titleBtnEliminar" does not exist.', 160, $this->source); })()), "html", null, true);
        echo "\">
  \t\t\t\t\tEliminar</button>
  \t\t\t</div>
  \t\t\t
  \t\t</div>
  \t</div><!-- /.card-footer -->
  
</div><!-- /.card -->


<div class=\"f_card\">

  \t<div class=\"row\">
  \t\t<div class=\"col-12\">
  \t\t\t<div class=\"f_cardheader\">
  \t\t\t\t<div class=\"\">Predios Vinculados</div>
  \t\t\t</div>
  \t\t</div>
  \t</div><!-- /.card-header -->
  \t
  \t
  \t<div class=\"row\">
      \t<div class=\"col-12 col-lg-6 table-responsive\">
          \t\t
  \t\t\t<table class=\"table f_table f_tableliste\">
  \t\t\t  <thead>
  \t\t\t  \t<tr class=\"liste_title\">
  \t\t\t  \t\t<td class=\"liste_title\" colspan=\"2\">Predios</td>
  \t\t\t  \t</tr>
  \t\t\t  </thead>
              <tbody>
              \t";
        // line 191
        if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "predios", [], "any", true, true, false, 191) &&  !twig_test_empty(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 191, $this->source); })()), "predios", [], "any", false, false, false, 191)))) {
            // line 192
            echo "                          \t
              \t\t";
            // line 193
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 193, $this->source); })()), "predios", [], "any", false, false, false, 193));
            foreach ($context['_seq'] as $context["_key"] => $context["predio"]) {
                // line 194
                echo "                        <tr class=\"f_oddeven\">
                          <td>
                              <a href=\"";
                // line 196
                echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 196, $this->source); })()), "html", null, true);
                echo "/predio/detalle/";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["predio"], "PRE_CODIGO", [], "any", false, false, false, 196), "html", null, true);
                echo "\" class=\"f_link\">
                          \t\t<span class=\"align-middtle\">";
                // line 197
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["predio"], "PRE_CODIGO", [], "any", false, false, false, 197), "html", null, true);
                echo "</span>
                              </a>
                          </td>
                          <td class=\"f_overflowmax150\">";
                // line 200
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["predio"], "PRE_DIRECCION", [], "any", false, false, false, 200), "html", null, true);
                echo "</td>
                        </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['predio'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 203
            echo "                
              \t";
        } else {
            // line 205
            echo "              \t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(0, 2));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 206
                echo "                  \t\t<tr>
\t\t\t\t\t\t\t<td>&nbsp;</td><td></td>
                        </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 210
            echo "              \t";
        }
        // line 211
        echo "              </tbody>
            </table>
      \t\t
    \t</div>
  \t</div><!-- /.card-body -->
  \t
  \t<div class=\"row\">
  \t\t<div class=\"col-12 f_cardfooter text-right\"></div>
  \t</div><!-- /.card-footer -->

</div><!-- /.card -->




";
        // line 227
        if ((twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "predios", [], "any", true, true, false, 227) && twig_test_empty(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 227, $this->source); })()), "predios", [], "any", false, false, false, 227)))) {
            // line 228
            echo "    <div class=\"modal fade f_modal\" id=\"modalEliminarCliente\" tabindex=\"-1\" role=\"dialog\" data-backdrop=\"static\" aria-hidden=\"true\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <span class=\"modal-title\">Eliminar un cliente</span>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                    \t<span aria-hidden=\"true\">&times;</span>
                    </button>
                </div>
                <div class=\"modal-body\">
                \t<i class=\"fas fa-info-circle text-secondary mr-1\"></i><span>¿Está seguro de querer eliminar este cliente?</span>
                \t<form class=\"d-none\" id=\"formEliminarCliente\" action=\"";
            // line 239
            echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 239, $this->source); })()), "html", null, true);
            echo "/cliente/delete\" method=\"post\">
                \t\t<input type=\"hidden\" name=\"codigo\" value=\"";
            // line 240
            if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "cliente", [], "any", true, true, false, 240)) {
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 240, $this->source); })()), "cliente", [], "any", false, false, false, 240), "CLI_CODIGO", [], "any", false, false, false, 240), "html", null, true);
            }
            echo "\">
                \t</form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"f_btnactionmodal\" id=\"btnEliminarCliente\">Si</button>
                    <button type=\"button\" class=\"f_btnactionmodal\" data-dismiss=\"modal\">No</button>
                </div>
            </div>
        </div>
    </div>
";
        }
        // line 252
        echo "    
";
    }

    // line 255
    public function block_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 256
        echo "
\t";
        // line 257
        $this->displayParentBlock("scripts", $context, $blocks);
        echo "
\t
\t<script type=\"text/javascript\">
\t\t\$('#btnEliminarCliente').click(function(event){
\t\t\t\$('#formEliminarCliente').submit();
\t\t\treturn false;
\t\t});
\t</script>
\t
";
    }

    public function getTemplateName()
    {
        return "/administration/cliente/clienteDetail.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  534 => 257,  531 => 256,  527 => 255,  522 => 252,  506 => 240,  502 => 239,  489 => 228,  487 => 227,  470 => 211,  467 => 210,  458 => 206,  453 => 205,  449 => 203,  440 => 200,  434 => 197,  428 => 196,  424 => 194,  420 => 193,  417 => 192,  415 => 191,  381 => 160,  376 => 159,  373 => 158,  369 => 156,  366 => 155,  363 => 154,  361 => 153,  352 => 151,  337 => 141,  328 => 137,  319 => 133,  310 => 129,  301 => 125,  292 => 121,  283 => 117,  278 => 114,  272 => 111,  268 => 109,  266 => 108,  263 => 107,  257 => 104,  253 => 102,  251 => 101,  243 => 98,  240 => 97,  237 => 96,  231 => 95,  229 => 94,  220 => 90,  217 => 89,  214 => 88,  208 => 87,  206 => 86,  200 => 82,  197 => 81,  191 => 79,  189 => 78,  184 => 77,  181 => 76,  179 => 75,  169 => 70,  158 => 62,  152 => 58,  148 => 57,  144 => 55,  140 => 54,  126 => 42,  120 => 37,  117 => 36,  108 => 34,  103 => 33,  101 => 32,  95 => 30,  92 => 29,  89 => 28,  86 => 27,  83 => 26,  80 => 25,  77 => 24,  74 => 23,  71 => 22,  54 => 6,  50 => 5,  45 => 3,  43 => 1,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("", "/administration/cliente/clienteDetail.twig", "/home/jasschos/public_html/resources/views/administration/cliente/clienteDetail.twig");
    }
}
