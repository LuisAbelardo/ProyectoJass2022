<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /administration/proyecto/proyectoNew.twig */
class __TwigTemplate_1843a408b4376f89c7db09f228d6b0a1e5c304e800d781b71be153268cd2f8d2 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content_main' => [$this, 'block_content_main'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "administration/templateAdministration.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        list($context["menuLItem"], $context["menuLLink"]) =         ["proyecto", "nuevo"];
        // line 3
        $this->parent = $this->loadTemplate("administration/templateAdministration.twig", "/administration/proyecto/proyectoNew.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "
<div class=\"f_card\">
\t";
        // line 9
        echo "\t<form class=\"f_inputflat\" id=\"formNuevoProyecto\" method=\"post\" action=\"";
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 9, $this->source); })()), "html", null, true);
        echo "/proyecto/create\">
\t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t<div class=\"f_cardheader\">
      \t\t\t\t<div class=\"\"> 
                    \t<i class=\"fas fa-project-diagram mr-3\"></i>Nuevo proyecto
                \t</div>
      \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-header -->
      \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t";
        // line 24
        echo "                ";
        $context["classAlert"] = "";
        // line 25
        echo "                ";
        if (twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 25, $this->source); })()))) {
            // line 26
            echo "                \t";
            $context["classAlert"] = "d-none";
            // line 27
            echo "                ";
        } elseif ((((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) >= 200) && ((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 27, $this->source); })()) < 300))) {
            // line 28
            echo "                    ";
            $context["classAlert"] = "alert-success";
            // line 29
            echo "                ";
        } elseif (((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 29, $this->source); })()) >= 400)) {
            // line 30
            echo "                    ";
            $context["classAlert"] = "alert-danger";
            // line 31
            echo "                ";
        }
        // line 32
        echo "      \t\t\t<div class=\"alert ";
        echo twig_escape_filter($this->env, (isset($context["classAlert"]) || array_key_exists("classAlert", $context) ? $context["classAlert"] : (function () { throw new RuntimeError('Variable "classAlert" does not exist.', 32, $this->source); })()), "html", null, true);
        echo " alert-dismissible fade show\" id=\"f_alertsContainer\" role=\"alert\">
                 \t<ul class=\"mb-0\" id=\"f_alertsUl\">
                 \t\t";
        // line 34
        if ( !twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 34, $this->source); })()))) {
            // line 35
            echo "                          ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 35, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["msj"]) {
                // line 36
                echo "                            <li>";
                echo twig_escape_filter($this->env, $context["msj"], "html", null, true);
                echo "</li>
                          ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "                        ";
        }
        // line 39
        echo "                 \t</ul>
                 \t<button type=\"button\" class=\"close\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\" id=\"f_alertsDismiss\">
                 \t\t<span aria-hidden=\"true\">&times;</span>
                 \t</button>
                </div>";
        // line 44
        echo "      \t\t</div>
      \t</div>
      \t
  
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t<div class=\"f_divwithbartop f_divwithbarbottom\">
      \t\t\t\t<div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpNombre\">Nombre</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                            ";
        // line 54
        $context["nombre"] = "";
        // line 55
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoProyecto", [], "any", true, true, false, 55)) {
            // line 56
            echo "                        \t    ";
            $context["nombre"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 56, $this->source); })()), "formNuevoProyecto", [], "any", false, false, false, 56), "nombre", [], "any", false, false, false, 56);
        }
        // line 57
        echo "                        \t<input type=\"text\" class=\"f_minwidth300\" id=\"inpNombre\" name=\"nombre\" required 
                        \t\t\tvalue='";
        // line 58
        echo twig_escape_filter($this->env, (isset($context["nombre"]) || array_key_exists("nombre", $context) ? $context["nombre"] : (function () { throw new RuntimeError('Variable "nombre" does not exist.', 58, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
      \t\t\t\t<div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpMontoPorContrato\">Monto por contrato</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                            ";
        // line 64
        $context["montoPorContrato"] = "";
        // line 65
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoProyecto", [], "any", true, true, false, 65)) {
            // line 66
            echo "                        \t    ";
            $context["montoPorContrato"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 66, $this->source); })()), "formNuevoProyecto", [], "any", false, false, false, 66), "montoPorContrato", [], "any", false, false, false, 66);
        }
        // line 67
        echo "                        \t<div style=\"background-color:#b9ceac\" class=\"d-inline-block\">
                        \t\t<span class=\"pl-1\">S/. </span>
                        \t\t<input type=\"text\" class=\"f_minwidth100\" id=\"inpMontoPorContrato\" name=\"montoPorContrato\" required
                        \t\t\tstyle=\"background-color:#b9ceac\" value='";
        // line 70
        echo twig_escape_filter($this->env, (isset($context["montoPorContrato"]) || array_key_exists("montoPorContrato", $context) ? $context["montoPorContrato"] : (function () { throw new RuntimeError('Variable "montoPorContrato" does not exist.', 70, $this->source); })()), "html", null, true);
        echo "'>
                        \t</div>
                        </div>
                    </div>
      \t\t\t\t<div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"inpNroCuotasPorContrato\">Nro. Cuotas por contrato</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                            ";
        // line 77
        $context["nroCuotasPorContrato"] = "";
        // line 78
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoProyecto", [], "any", true, true, false, 78)) {
            // line 79
            echo "                        \t    ";
            $context["nroCuotasPorContrato"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 79, $this->source); })()), "formNuevoProyecto", [], "any", false, false, false, 79), "nroCuotasPorContrato", [], "any", false, false, false, 79);
        }
        // line 80
        echo "                        \t<input type=\"text\" class=\"f_minwidth100\" id=\"inpNroCuotasPorContrato\" name=\"nroCuotasPorContrato\" required 
                        \t\t\tvalue='";
        // line 81
        echo twig_escape_filter($this->env, (isset($context["nroCuotasPorContrato"]) || array_key_exists("nroCuotasPorContrato", $context) ? $context["nroCuotasPorContrato"] : (function () { throw new RuntimeError('Variable "nroCuotasPorContrato" does not exist.', 81, $this->source); })()), "html", null, true);
        echo "'>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                    \t<label class=\"col-12 col-md-3 col-lg-2 f_fieldrequired\" for=\"txaDescripcion\">Descripción</label>
                        <div class=\"col-12 col-md-9 col-lg-10\">
                        \t";
        // line 87
        $context["descripcion"] = "";
        // line 88
        echo "                        \t";
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formNuevoProyecto", [], "any", false, true, false, 88), "descripcion", [], "any", true, true, false, 88)) {
            // line 89
            echo "                        \t    ";
            $context["descripcion"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 89, $this->source); })()), "formNuevoProyecto", [], "any", false, false, false, 89), "descripcion", [], "any", false, false, false, 89);
        }
        // line 90
        echo "                        \t<textarea class=\"f_minwidth400\" id=\"txaDescripcion\" rows=\"2\" maxlength=\"256\" required
                        \t\t\t\tname=\"descripcion\">";
        // line 91
        echo twig_escape_filter($this->env, (isset($context["descripcion"]) || array_key_exists("descripcion", $context) ? $context["descripcion"] : (function () { throw new RuntimeError('Variable "descripcion" does not exist.', 91, $this->source); })()), "html", null, true);
        echo "</textarea>
                        </div>
                    </div>
      \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-body -->
  \t
      \t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t<div class=\"f_cardfooter f_cardfooteractions text-center\">
        \t\t\t<button type=\"submit\" class=\"f_button f_buttonaction\">Guardar</button>
        \t\t\t<a href=\"";
        // line 102
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 102, $this->source); })()), "html", null, true);
        echo "/proyecto/lista\" class=\"f_linkbtn f_linkbtnaction\">Cancelar</a>
    \t\t\t</div>
      \t\t</div>
      \t</div><!-- /.card-footer -->
  \t
  \t</form>";
        // line 108
        echo "  
</div><!-- /.card -->

";
    }

    // line 113
    public function block_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 114
        echo "
    ";
        // line 115
        $this->displayParentBlock("scripts", $context, $blocks);
        echo "
  
\t<script type=\"text/javascript\">
\t\t\$('#formNuevoProyecto').keypress(function(e) {
            if (e.which == 13) {
                return false;
            }
        });
        
\t</script>
";
    }

    public function getTemplateName()
    {
        return "/administration/proyecto/proyectoNew.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  257 => 115,  254 => 114,  250 => 113,  243 => 108,  235 => 102,  221 => 91,  218 => 90,  214 => 89,  211 => 88,  209 => 87,  200 => 81,  197 => 80,  193 => 79,  190 => 78,  188 => 77,  178 => 70,  173 => 67,  169 => 66,  166 => 65,  164 => 64,  155 => 58,  152 => 57,  148 => 56,  145 => 55,  143 => 54,  131 => 44,  125 => 39,  122 => 38,  113 => 36,  108 => 35,  106 => 34,  100 => 32,  97 => 31,  94 => 30,  91 => 29,  88 => 28,  85 => 27,  82 => 26,  79 => 25,  76 => 24,  58 => 9,  54 => 6,  50 => 5,  45 => 3,  43 => 1,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("", "/administration/proyecto/proyectoNew.twig", "/home/jasschos/public_html/resources/views/administration/proyecto/proyectoNew.twig");
    }
}
