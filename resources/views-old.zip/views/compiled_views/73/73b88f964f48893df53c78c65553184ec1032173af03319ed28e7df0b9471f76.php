<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /administration/usuario/userList.twig */
class __TwigTemplate_815bc33c0ef4ae7fd6bb3daca602eeb46c5a8b22c390b1423bdbfbbbd71d6aae extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content_main' => [$this, 'block_content_main'],
            'scripts' => [$this, 'block_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "administration/templateAdministration.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        list($context["menuLItem"], $context["menuLLink"]) =         ["usuario", "lista"];
        // line 3
        $this->parent = $this->loadTemplate("administration/templateAdministration.twig", "/administration/usuario/userList.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "\t
<div class=\"f_card\">
\t";
        // line 9
        echo "  \t<form method=\"get\" action=\"";
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 9, $this->source); })()), "html", null, true);
        echo "/usuario/lista/filtro\" id=\"formFilterListUsers\">
  \t
  \t\t<div class=\"row\">
  \t\t\t<div class=\"col-12\">
  \t\t\t\t<div class=\"f_cardheader\">
                    <div> 
                    \t<i class=\"fas fa-user-shield mr-3\"></i>Listado de usuarios 
                    \t<span>(";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 16, $this->source); })()), "pagination", [], "any", false, false, false, 16), "paginaCantidadRegistros", [], "any", false, false, false, 16), "html", null, true);
        echo ")</span>
                \t</div>
                  </div>
  \t\t\t</div>
  \t\t</div><!-- /.card-header -->
  \t\t
  \t\t<div class=\"row\">
      \t\t<div class=\"col-12\">
      \t\t\t";
        // line 25
        echo "                ";
        $context["classAlert"] = "";
        // line 26
        echo "                ";
        if (twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 26, $this->source); })()))) {
            // line 27
            echo "                \t";
            $context["classAlert"] = "d-none";
            // line 28
            echo "                ";
        } elseif ((((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 28, $this->source); })()) >= 200) && ((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 28, $this->source); })()) < 300))) {
            // line 29
            echo "                    ";
            $context["classAlert"] = "alert-success";
            // line 30
            echo "                ";
        } elseif (((isset($context["codigo"]) || array_key_exists("codigo", $context) ? $context["codigo"] : (function () { throw new RuntimeError('Variable "codigo" does not exist.', 30, $this->source); })()) >= 400)) {
            // line 31
            echo "                    ";
            $context["classAlert"] = "alert-danger";
            // line 32
            echo "                ";
        }
        // line 33
        echo "      \t\t\t<div class=\"alert ";
        echo twig_escape_filter($this->env, (isset($context["classAlert"]) || array_key_exists("classAlert", $context) ? $context["classAlert"] : (function () { throw new RuntimeError('Variable "classAlert" does not exist.', 33, $this->source); })()), "html", null, true);
        echo " alert-dismissible fade show\" id=\"f_alertsContainer\" role=\"alert\">
                 \t<ul class=\"mb-0\" id=\"f_alertsUl\">
                 \t\t";
        // line 35
        if ( !twig_test_empty((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 35, $this->source); })()))) {
            // line 36
            echo "                          ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["estadoDetalle"]) || array_key_exists("estadoDetalle", $context) ? $context["estadoDetalle"] : (function () { throw new RuntimeError('Variable "estadoDetalle" does not exist.', 36, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["msj"]) {
                // line 37
                echo "                            <li>";
                echo twig_escape_filter($this->env, $context["msj"], "html", null, true);
                echo "</li>
                          ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 39
            echo "                        ";
        }
        // line 40
        echo "                 \t</ul>
                 \t<button type=\"button\" class=\"close\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\" id=\"f_alertsDismiss\">
                 \t\t<span aria-hidden=\"true\">&times;</span>
                 \t</button>
                </div>";
        // line 45
        echo "      \t\t</div>
      \t</div>
      \t
  \t\t
  \t\t<div class=\"row\">
  \t\t\t<div class=\"col-12\">
  \t\t\t
  \t\t\t\t";
        // line 53
        echo "  \t\t\t\t<div class=\"d-flex justify-content-end align-items-center pb-2\">
  \t\t\t\t\t<div>
                    \t<ul class=\"pagination f_pagination-basic pagination-sm m-0\">
                            <li class=\"page-item ";
        // line 56
        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 56, $this->source); })()), "pagination", [], "any", false, false, false, 56), "paginaAnterior", [], "any", false, false, false, 56) ==  -1)) {
            echo "disabled";
        }
        echo "\">
                            \t<a class=\"page-link\"
                            \t\tid=\"paginaAnterior\" 
                            \t\tdata-page=\"";
        // line 59
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 59, $this->source); })()), "pagination", [], "any", false, false, false, 59), "paginaAnterior", [], "any", false, false, false, 59), "html", null, true);
        echo "\" 
                            \t\thref=\"#\" ><i class=\"fas fa-chevron-left\"></i></a>
                        \t</li>
                            <li class=\"page-item\">
                            \t<span class=\"page-link info\">
                                \t<input type=\"text\" id=\"filterPaginaActual\" name=\"filterPaginaActual\" class=\"f_inputflat\" required size=\"10\"
                            \t\t\t\tvalue=\"";
        // line 65
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 65, $this->source); })()), "pagination", [], "any", false, false, false, 65), "paginaActual", [], "any", false, false, false, 65), "html", null, true);
        echo "\">
                        \t\t\tde ";
        // line 66
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 66, $this->source); })()), "pagination", [], "any", false, false, false, 66), "paginaCantidad", [], "any", false, false, false, 66), "html", null, true);
        echo "
                            \t</span>
                            </li>
                            <li class=\"page-item ";
        // line 69
        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 69, $this->source); })()), "pagination", [], "any", false, false, false, 69), "paginaSiguiente", [], "any", false, false, false, 69) ==  -1)) {
            echo "disabled";
        }
        echo "\">
                            \t<a class=\"page-link\" id=\"paginaSiguiente\"
                            \t\tdata-page=\"";
        // line 71
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 71, $this->source); })()), "pagination", [], "any", false, false, false, 71), "paginaSiguiente", [], "any", false, false, false, 71), "html", null, true);
        echo "\"
                            \t\thref=\"#\"><i class=\"fas fa-chevron-right\"></i></a>
                        \t</li>
                        </ul>
                    </div>
                    <div class=\"px-2\">
                    \t<button type=\"submit\" class=\"f_btnflat\" name=\"btnBuscarFiltros\">
                    \t\t<span class=\"fas fa-search\"></span>
                \t\t</button>
                \t\t<a href=\"";
        // line 80
        echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 80, $this->source); })()), "html", null, true);
        echo "/usuario/lista\" class=\"f_link\">
                \t\t\t<i class=\"fas fa-times\"></i>
            \t\t\t</a>
                    </div>
  \t\t\t\t</div>";
        // line 85
        echo "  \t\t\t\t
  \t\t\t\t
      \t\t\t<div class=\"table-responsive\">
                    <table class=\"table f_table f_tableliste f_listwidthfilterbefore\">
                      <thead>
                      \t<tr class=\"liste_title_filter\">
                          <td class=\"liste_title f_minwidth125\">
                          \t<i class=\"fas fa-filter mr-1\"></i>
    \t\t\t\t\t\t<input class=\"f_inputflat f_maxwidth80imp\" type=\"text\" name=\"filterCodigo\"  disabled
                          \t\tvalue='";
        // line 94
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formFilterListUsers", [], "any", false, true, false, 94), "filterCodigo", [], "any", true, true, false, 94)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 94, $this->source); })()), "formFilterListUsers", [], "any", false, false, false, 94), "filterCodigo", [], "any", false, false, false, 94), "html", null, true);
        }
        echo "'></td>
                    \t  <td class=\"liste_title\">
                    \t  \t<input class=\"f_inputflat f_maxwidth100imp\" type=\"text\" name=\"filterUsuario\" disabled
                    \t  \t\tvalue=\"";
        // line 97
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formFilterListUsers", [], "any", false, true, false, 97), "filterUsuario", [], "any", true, true, false, 97)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 97, $this->source); })()), "formFilterListUsers", [], "any", false, false, false, 97), "filterUsuario", [], "any", false, false, false, 97), "html", null, true);
        }
        echo "\"></td>
                          <td class=\"liste_title\">
                          \t<input class=\"f_inputflat f_maxwidth100imp\" type=\"text\" name=\"filterNombres\"
                          \t\tvalue=\"";
        // line 100
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formFilterListUsers", [], "any", false, true, false, 100), "filterNombres", [], "any", true, true, false, 100)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 100, $this->source); })()), "formFilterListUsers", [], "any", false, false, false, 100), "filterNombres", [], "any", false, false, false, 100), "html", null, true);
        }
        echo "\"></td>
                          <td class=\"liste_title\">
                          \t<input class=\"f_inputflat f_maxwidth100imp\" type=\"text\" name=\"filterApellidos\"
                          \t\tvalue=\"";
        // line 103
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formFilterListUsers", [], "any", false, true, false, 103), "filterApellidos", [], "any", true, true, false, 103)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 103, $this->source); })()), "formFilterListUsers", [], "any", false, false, false, 103), "filterApellidos", [], "any", false, false, false, 103), "html", null, true);
        }
        echo "\"></td>
                          <td class=\"liste_title\">
                          \t<input class=\"f_inputflat f_maxwidth100imp\" type=\"text\" name=\"filterEmail\" disabled
                          \t\tvalue=\"";
        // line 106
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formFilterListUsers", [], "any", false, true, false, 106), "filterEmail", [], "any", true, true, false, 106)) {
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 106, $this->source); })()), "formFilterListUsers", [], "any", false, false, false, 106), "filterEmail", [], "any", false, false, false, 106), "html", null, true);
        }
        echo "\"></td>
                          <td class=\"liste_title\">
                          \t<select class=\"f_inputflat\" name=\"filterTipo\" id=\"cmbFilterTipo\">
                                <option value=\"-1\" class=\"f_opacitymedium\"></option>
                                ";
        // line 110
        if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuarioTipos", [], "any", true, true, false, 110)) {
            // line 111
            echo "                                    ";
            $context["selectedFilterTipo"] = false;
            // line 112
            echo "                            \t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 112, $this->source); })()), "usuarioTipos", [], "any", false, false, false, 112));
            foreach ($context['_seq'] as $context["_key"] => $context["tipoUsuario"]) {
                // line 113
                echo "                                    \t<option value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["tipoUsuario"], "TPU_CODIGO", [], "any", false, false, false, 113), "html", null, true);
                echo "\"
                                \t\t\t\t";
                // line 114
                if ((( !(isset($context["selectedFilterTipo"]) || array_key_exists("selectedFilterTipo", $context) ? $context["selectedFilterTipo"] : (function () { throw new RuntimeError('Variable "selectedFilterTipo" does not exist.', 114, $this->source); })()) && twig_get_attribute($this->env, $this->source,                 // line 115
($context["data"] ?? null), "formFilterListUsers", [], "any", true, true, false, 115)) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source,                 // line 116
(isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 116, $this->source); })()), "formFilterListUsers", [], "any", false, false, false, 116), "filterTipo", [], "any", false, false, false, 116) == twig_get_attribute($this->env, $this->source, $context["tipoUsuario"], "TPU_CODIGO", [], "any", false, false, false, 116)))) {
                    // line 117
                    echo "                    \t\t\t\t\t            ";
                    echo "selected";
                    $context["selectedFilterTipo"] = true;
                }
                echo ">
                            \t\t\t\t";
                // line 118
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["tipoUsuario"], "TPU_NOMBRE", [], "any", false, false, false, 118), "html", null, true);
                echo "
                        \t\t\t\t</option>
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tipoUsuario'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 121
            echo "                            \t";
        }
        // line 122
        echo "                              </select>
                          </td>
                          <td class=\"liste_title\">
                          \t<select class=\"f_inputflat\" name=\"filterEstado\" id=\"cmbFilterEstado\">
                                <option value=\"-1\" class=\"f_opacitymedium\"></option>
                                <option value=\"0\" 
                                    ";
        // line 128
        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formFilterListUsers", [], "any", false, true, false, 128), "filterEstado", [], "any", true, true, false, 128) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 128, $this->source); })()), "formFilterListUsers", [], "any", false, false, false, 128), "filterEstado", [], "any", false, false, false, 128) == "0"))) {
            // line 129
            echo "                        \t\t\t\t\t";
            echo "selected";
            echo "
                \t\t\t\t\t";
        }
        // line 130
        echo ">
                \t\t\t\t\tSuspendido
            \t\t\t\t\t</option>
                                <option value=\"1\"
                                    ";
        // line 134
        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "formFilterListUsers", [], "any", false, true, false, 134), "filterEstado", [], "any", true, true, false, 134) && (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 134, $this->source); })()), "formFilterListUsers", [], "any", false, false, false, 134), "filterEstado", [], "any", false, false, false, 134) == "1"))) {
            // line 135
            echo "                        \t\t\t\t\t";
            echo "selected";
            echo "
                \t\t\t\t\t";
        }
        // line 136
        echo ">
                \t\t\t\t\tActivo
            \t\t\t\t\t</option>
                              </select>
                          </td>
                        </tr>
                        <tr class=\"liste_title\">
                          <th class=\"wrapcolumntitle liste_title\">Ref.</th>
                          <th class=\"wrapcolumntitle liste_title\">Usuario</th>
                          <th class=\"wrapcolumntitle liste_title\">Nombres</th>
                          <th class=\"wrapcolumntitle liste_title\">Apellidos</th>
                          <th class=\"wrapcolumntitle liste_title\">Email</th>
                          <th class=\"wrapcolumntitle liste_title\">Tipo</th>
                          <th class=\"wrapcolumntitle liste_title\">Estado</th>
                        </tr>
                      </thead>
                      <tbody>
                      
                      \t";
        // line 154
        if ( !twig_test_empty(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 154, $this->source); })()), "users", [], "any", false, false, false, 154))) {
            // line 155
            echo "                      \t
                      \t\t";
            // line 156
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 156, $this->source); })()), "users", [], "any", false, false, false, 156));
            foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
                // line 157
                echo "                                <tr class=\"f_oddeven\">
                                  <td>
                                      <a href=\"";
                // line 159
                echo twig_escape_filter($this->env, (isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 159, $this->source); })()), "html", null, true);
                echo "/usuario/detalle/";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "USU_CODIGO", [], "any", false, false, false, 159), "html", null, true);
                echo "\" class=\"f_link\">
                                  \t\t<span>
                                  \t\t\t";
                // line 161
                $context["userAvatar"] = ((isset($context["PUBLIC_PATH"]) || array_key_exists("PUBLIC_PATH", $context) ? $context["PUBLIC_PATH"] : (function () { throw new RuntimeError('Variable "PUBLIC_PATH" does not exist.', 161, $this->source); })()) . "/img/user_default_table.png");
                // line 162
                echo "                                  \t\t\t";
                if ((twig_get_attribute($this->env, $this->source, $context["user"], "USU_FOTO", [], "any", true, true, false, 162) &&  !twig_test_empty(twig_get_attribute($this->env, $this->source, $context["user"], "USU_FOTO", [], "any", false, false, false, 162)))) {
                    // line 163
                    echo "                                  \t\t\t    ";
                    $context["userAvatar"] = twig_get_attribute($this->env, $this->source, $context["user"], "USU_FOTO", [], "any", false, false, false, 163);
                }
                // line 164
                echo "                                  \t\t\t<img class=\"f_imageavatartable align-middle mr-1\" alt=\"\"
                                  \t\t\t\t\tsrc=\"";
                // line 165
                echo twig_escape_filter($this->env, (isset($context["userAvatar"]) || array_key_exists("userAvatar", $context) ? $context["userAvatar"] : (function () { throw new RuntimeError('Variable "userAvatar" does not exist.', 165, $this->source); })()), "html", null, true);
                echo "\">
                              \t\t\t</span>
                                  \t\t<span class=\"align-middtle\">";
                // line 167
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "USU_CODIGO", [], "any", false, false, false, 167), "html", null, true);
                echo "</span>
                                      </a>
                                  </td>
                                  <td class=\"f_overflowmax150\">";
                // line 170
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "USU_USUARIO", [], "any", false, false, false, 170), "html", null, true);
                echo "</td>
                                  <td class=\"f_overflowmax250\">";
                // line 171
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "USU_NOMBRES", [], "any", false, false, false, 171), "html", null, true);
                echo "</td>
                                  <td class=\"f_overflowmax250\">";
                // line 172
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "USU_APELLIDOS", [], "any", false, false, false, 172), "html", null, true);
                echo "</td>
                                  <td class=\"f_overflowmax150\">";
                // line 173
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "USU_EMAIL", [], "any", false, false, false, 173), "html", null, true);
                echo "</td>
                                  <td class=\"f_overflowmax150\">
    \t\t\t\t\t\t\t\t";
                // line 175
                if (twig_get_attribute($this->env, $this->source, ($context["data"] ?? null), "usuarioTipos", [], "any", true, true, false, 175)) {
                    // line 176
                    echo "    \t\t\t\t\t\t\t\t\t";
                    $context["selectedUsuarioTipo"] = false;
                    // line 177
                    echo "    \t\t\t\t\t\t\t\t\t";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 177, $this->source); })()), "usuarioTipos", [], "any", false, false, false, 177));
                    foreach ($context['_seq'] as $context["_key"] => $context["usuarioTipo"]) {
                        if ( !(isset($context["selectedUsuarioTipo"]) || array_key_exists("selectedUsuarioTipo", $context) ? $context["selectedUsuarioTipo"] : (function () { throw new RuntimeError('Variable "selectedUsuarioTipo" does not exist.', 177, $this->source); })())) {
                            // line 178
                            echo "    \t\t\t\t\t\t\t\t\t\t";
                            if ((twig_get_attribute($this->env, $this->source, $context["usuarioTipo"], "TPU_CODIGO", [], "any", false, false, false, 178) == twig_get_attribute($this->env, $this->source, $context["user"], "TPU_CODIGO", [], "any", false, false, false, 178))) {
                                // line 179
                                echo "    \t\t\t\t\t\t\t\t\t\t\t";
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["usuarioTipo"], "TPU_NOMBRE", [], "any", false, false, false, 179), "html", null, true);
                                $context["selectedUsuarioTipo"] = true;
                                // line 180
                                echo "    \t\t\t\t\t\t\t\t\t\t";
                            }
                            // line 181
                            echo "    \t\t\t\t\t\t\t\t\t";
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['usuarioTipo'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 182
                    echo "    \t\t\t\t\t\t\t\t";
                }
                // line 183
                echo "                                  </td>
                                  <td class=\"f_overflowmax150\">
                                      ";
                // line 185
                if ((twig_get_attribute($this->env, $this->source, $context["user"], "USU_ESTADO", [], "any", false, false, false, 185) == 0)) {
                    // line 186
                    echo "                                      \t<span class=\"badge badge-danger\">";
                    echo "Suspendido";
                    echo "</span>
                                      ";
                } elseif ((twig_get_attribute($this->env, $this->source,                 // line 187
$context["user"], "USU_ESTADO", [], "any", false, false, false, 187) == 1)) {
                    // line 188
                    echo "                                      \t<span class=\"badge badge-success\">";
                    echo "Activo";
                    echo "</span>
                                      ";
                }
                // line 190
                echo "                                  </td>
                                </tr>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 193
            echo "                        
                      \t";
        } else {
            // line 195
            echo "                      \t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(0, 3));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 196
                echo "                          \t\t<tr>
        \t\t\t\t\t\t\t<td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td>
                                </tr>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 200
            echo "                      \t";
        }
        // line 201
        echo "                      
                      \t
                      </tbody>
                    </table>
                </div>
  \t\t\t</div>
  \t\t\t
  \t\t</div><!-- /.card-body -->
  \t\t
  \t\t<div class=\"row\">
      \t\t<div class=\"col-12 f_cardfooter text-right\"></div>
      \t</div><!-- /.card-footer -->
  \t\t
    </form>";
        // line 215
        echo "    
</div><!-- /.card -->
    
";
    }

    // line 220
    public function block_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 221
        echo "
\t";
        // line 222
        $this->displayParentBlock("scripts", $context, $blocks);
        echo "
\t
\t<script type=\"text/javascript\">
\t\t\$('#paginaAnterior').click(function(event){
\t\t\tif(\$('#paginaAnterior').attr(\"data-page\") != -1){
\t\t\t\t\$('#filterPaginaActual').val(parseInt(\$('#filterPaginaActual').val()) - 1);
\t\t\t\t\$('#formFilterListUsers').submit();
\t\t\t}
\t\t\treturn false;
\t\t});
\t\t
\t\t\$('#paginaSiguiente').click(function(event){
\t\t\tif(\$('#paginaSiguiente').attr(\"data-page\") != -1){
\t\t\t\t\$('#filterPaginaActual').val(parseInt(\$('#filterPaginaActual').val()) + 1);
\t\t\t\t\$('#formFilterListUsers').submit();
\t\t\t}
\t\t\treturn false;
\t\t});
        
        f_select2(\"#cmbFilterEstado\");
        f_select2(\"#cmbFilterTipo\");
\t</script>
\t
";
    }

    public function getTemplateName()
    {
        return "/administration/usuario/userList.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  510 => 222,  507 => 221,  503 => 220,  496 => 215,  481 => 201,  478 => 200,  469 => 196,  464 => 195,  460 => 193,  452 => 190,  446 => 188,  444 => 187,  439 => 186,  437 => 185,  433 => 183,  430 => 182,  423 => 181,  420 => 180,  416 => 179,  413 => 178,  407 => 177,  404 => 176,  402 => 175,  397 => 173,  393 => 172,  389 => 171,  385 => 170,  379 => 167,  374 => 165,  371 => 164,  367 => 163,  364 => 162,  362 => 161,  355 => 159,  351 => 157,  347 => 156,  344 => 155,  342 => 154,  322 => 136,  316 => 135,  314 => 134,  308 => 130,  302 => 129,  300 => 128,  292 => 122,  289 => 121,  280 => 118,  273 => 117,  271 => 116,  270 => 115,  269 => 114,  264 => 113,  259 => 112,  256 => 111,  254 => 110,  245 => 106,  237 => 103,  229 => 100,  221 => 97,  213 => 94,  202 => 85,  195 => 80,  183 => 71,  176 => 69,  170 => 66,  166 => 65,  157 => 59,  149 => 56,  144 => 53,  135 => 45,  129 => 40,  126 => 39,  117 => 37,  112 => 36,  110 => 35,  104 => 33,  101 => 32,  98 => 31,  95 => 30,  92 => 29,  89 => 28,  86 => 27,  83 => 26,  80 => 25,  69 => 16,  58 => 9,  54 => 6,  50 => 5,  45 => 3,  43 => 1,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("", "/administration/usuario/userList.twig", "/home/jasschos/public_html/resources/views/administration/usuario/userList.twig");
    }
}
